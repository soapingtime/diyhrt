var figure = {
    "data": [
        {
            "meta": {
                "columnNames": {
                    "x": "F82, x",
                    "y": "F82, y"
                }
            },
            "mode": "lines",
            "name": "Fotherby (1982) EC susp. 5 mg i.m. [n=3–11]",
            "type": "scatter",
            "xsrc": "transfemscience:6:6eadf0",
            "x": [
                "0",
                "1",
                "3",
                "4",
                "7",
                "8",
                "10",
                "11",
                "14",
                "15",
                "17",
                "18"
            ],
            "ysrc": "transfemscience:6:b61eb4",
            "y": [
                "151.84250269598",
                "372.23087545886",
                "193.86132794955",
                "271.09895090291",
                "153.12379812633",
                "191.03597187085",
                "116.64877654399",
                "125.94011235215",
                "79.726303961558",
                "79.828315724885",
                "89.629057822399",
                "79.075133947536"
            ]
        },
        {
            "meta": {
                "columnNames": {
                    "x": "A85, x",
                    "y": "A85, y"
                }
            },
            "mode": "lines",
            "name": "Aedo (1985) EC susp. 5 mg i.m. [n=8]",
            "type": "scatter",
            "xsrc": "transfemscience:6:27bca3",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4",
                "5",
                "6",
                "7",
                "8",
                "9",
                "10",
                "11",
                "12",
                "13",
                "14",
                "15",
                "16",
                "17",
                "18",
                "19",
                "20",
                "21",
                "22",
                "23",
                "24",
                "25",
                "26",
                "27",
                "28",
                "29",
                "30"
            ],
            "ysrc": "transfemscience:6:be7f0d",
            "y": [
                "0",
                "174.8372997",
                "208.0432195",
                "220.2122555",
                "248.0529215",
                "148.1609816",
                "213.9871738",
                "195.1927262",
                "170.7381568",
                "147.1780156",
                "128.9402531",
                "92.20617706",
                "48.15097207",
                "122.8175139",
                "59.17891522",
                "68.82404412",
                "102.4915222",
                "64.19868462",
                "74.10057052",
                "48.12310263",
                "64.31695853",
                "32.59491605",
                "73.09518578",
                "56.85285427",
                "80.72402628",
                "74.81480318",
                "110.9290262",
                "62.99815844",
                "184.6039751",
                "118.9493977",
                "46.32887592"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "G87a, x",
                    "y": "G87a, y"
                }
            },
            "mode": "lines",
            "name": "Garza-Flores (1987/1994a) EC susp. 5 mg i.m. [n=7]",
            "type": "scatter",
            "xsrc": "transfemscience:6:124238",
            "x": [
                "0",
                "2"
            ],
            "ysrc": "transfemscience:6:d5b65d",
            "y": [
                "40",
                "736"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "G87b, x",
                    "y": "G87b, y"
                }
            },
            "mode": "lines",
            "name": "Garza-Flores (1987/1994b) EC susp. 5 mg i.m. [n=8]",
            "type": "scatter",
            "xsrc": "transfemscience:6:618fa3",
            "x": [
                "0",
                "3"
            ],
            "ysrc": "transfemscience:6:4994a3",
            "y": [
                "40",
                "184"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "G87c, x",
                    "y": "G87c, y"
                }
            },
            "mode": "lines",
            "name": "Garza-Flores (1987/1994c) EC susp. 5 mg i.m. [n=7]",
            "type": "scatter",
            "xsrc": "transfemscience:6:f9859e",
            "x": [
                "0",
                "3"
            ],
            "ysrc": "transfemscience:6:a6e7ff",
            "y": [
                "40",
                "202"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "G87d, x",
                    "y": "G87d, y"
                }
            },
            "mode": "lines",
            "name": "Garza-Flores (1987d) EC susp. 2.5 mg i.m. [n=8]",
            "type": "scatter",
            "xsrc": "transfemscience:6:871240",
            "x": [
                "0",
                "2"
            ],
            "ysrc": "transfemscience:6:9e1b83",
            "y": [
                "40",
                "303"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "G87e, x",
                    "y": "G87e, y"
                }
            },
            "mode": "lines",
            "name": "Garza-Flores (1987e) EC susp. 2.5 mg i.m. [n=8]",
            "type": "scatter",
            "xsrc": "transfemscience:6:e9d69e",
            "x": [
                "0",
                "3"
            ],
            "ysrc": "transfemscience:6:58ffad",
            "y": [
                "40",
                "146"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "G87f, x",
                    "y": "G87f, y"
                }
            },
            "mode": "lines",
            "name": "Garza-Flores (1987f) EC susp. 2.5 mg i.m. [n=6]",
            "type": "scatter",
            "xsrc": "transfemscience:6:41c71e",
            "x": [
                "0",
                "4"
            ],
            "ysrc": "transfemscience:6:38fbca",
            "y": [
                "40",
                "94.8"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "Z98, x",
                    "y": "Z98, y"
                }
            },
            "mode": "lines",
            "name": "Zhou (1998) EC susp. 5 mg i.m. [n=9]",
            "type": "scatter",
            "xsrc": "transfemscience:6:40326b",
            "x": [
                "0",
                "1",
                "3",
                "5",
                "7",
                "14",
                "21",
                "28"
            ],
            "ysrc": "transfemscience:6:00d0fb",
            "y": [
                "78.82982016",
                "322.3513731",
                "271.1274302",
                "277.4284133",
                "231.6828234",
                "158.0878645",
                "119.493788",
                "93.22711537"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "R99, x",
                    "y": "R99, y"
                }
            },
            "mode": "lines",
            "name": "Rahimy (1999) EC susp. 5 mg i.m. [n=14]",
            "type": "scatter",
            "xsrc": "transfemscience:6:07ebea",
            "x": [
                "0",
                "1",
                "3",
                "5",
                "7",
                "10",
                "12",
                "14",
                "18",
                "21",
                "28"
            ],
            "ysrc": "transfemscience:6:676b72",
            "y": [
                "42.04573031",
                "214.7910801",
                "182.1640024",
                "168.045801",
                "152.4350623",
                "119.8079845",
                "96.13613071",
                "79.62845598",
                "57.150632",
                "45.41907668",
                "42.64203843"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "SR11im, x",
                    "y": "SR11im, y"
                }
            },
            "mode": "lines",
            "name": "Sierra-Ramírez (2011) EC susp. 5 mg i.m. [n=15]",
            "type": "scatter",
            "xsrc": "transfemscience:6:85708b",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4",
                "5",
                "6",
                "7",
                "8",
                "9",
                "10",
                "11",
                "12",
                "13",
                "14",
                "15",
                "16",
                "17",
                "18",
                "19",
                "20",
                "21",
                "22",
                "23",
                "24",
                "25",
                "26",
                "27",
                "28",
                "29",
                "30"
            ],
            "ysrc": "transfemscience:6:4768d8",
            "y": [
                "36.06807702",
                "337.578884",
                "287.6242223",
                "267.9823352",
                "238.509278",
                "219.6855189",
                "195.9484472",
                "167.2935179",
                "153.38648",
                "143.5757631",
                "85.42845967",
                "111.6653666",
                "68.26481833",
                "68.28527153",
                "68.30572472",
                "56.85647943",
                "52.78061174",
                "41.33250273",
                "42.99148429",
                "44.65046584",
                "30.74229172",
                "35.67946628",
                "31.60359858",
                "39.81669356",
                "30.00597662",
                "34.12275071",
                "34.96246808",
                "25.97101533",
                "44.83454461",
                "34.2045635",
                "47.33324354"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "SR11sc, x",
                    "y": "SR11sc, y"
                }
            },
            "mode": "lines",
            "name": "Sierra-Ramírez (2011) EC susp. 5 mg s.c. [n=15]",
            "type": "scatter",
            "xsrc": "transfemscience:6:bd0207",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4",
                "5",
                "6",
                "7",
                "8",
                "9",
                "10",
                "11",
                "12",
                "13",
                "14",
                "15",
                "16",
                "17",
                "18",
                "19",
                "20",
                "21",
                "22",
                "23",
                "24",
                "25",
                "26",
                "27",
                "28",
                "29",
                "30"
            ],
            "ysrc": "transfemscience:6:4719b6",
            "y": [
                "41.80292627",
                "350.6859745",
                "325.3092382",
                "297.4747094",
                "268.0027884",
                "246.7212367",
                "222.1649009",
                "179.5824805",
                "139.458989",
                "202.5627839",
                "114.9231064",
                "114.9424233",
                "91.2053516",
                "68.28640781",
                "91.2451217",
                "58.49500779",
                "74.90074454",
                "51.98293705",
                "53.64078231",
                "46.28785791",
                "37.29640515",
                "43.05170759",
                "36.51918365",
                "36.53850056",
                "37.37821794",
                "49.68877009",
                "42.33584569",
                "48.09114813",
                "43.19601626",
                "58.78248883",
                "44.05618683"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "T13, x",
                    "y": "T13, y"
                }
            },
            "mode": "lines",
            "name": "Thurman (2013) EC susp. 5 mg i.m. [n=15]",
            "type": "scatter",
            "xsrc": "transfemscience:6:45c48f",
            "x": [
                "0",
                "1",
                "3",
                "5",
                "7",
                "10",
                "12",
                "14",
                "18",
                "21",
                "28"
            ],
            "ysrc": "transfemscience:6:1b7fcb",
            "y": [
                "50.77562813",
                "231.1868534",
                "189.7018026",
                "207.3610472",
                "197.7554939",
                "165.4989339",
                "124.0138832",
                "99.3073559",
                "77.53707024",
                "55.76708744",
                "41.54713735"
            ],
            "stackgroup": null
        }
    ],
    "layout": {
        "font": {
            "color": "rgb(68, 68, 68)"
        },
        "width": 725,
        "xaxis": {
            "type": "linear",
            "dtick": 2,
            "range": [
                -0.5,
                30.5
            ],
            "title": {
                "text": "Time (days)"
            },
            "tickmode": "linear",
            "autorange": false,
            "zerolinecolor": "rgb(68, 68, 68)",
            "zerolinewidth": 1
        },
        "yaxis": {
            "type": "linear",
            "range": [
                -5,
                425
            ],
            "title": {
                "text": "Estradiol levels (pg/mL)"
            },
            "autorange": false,
            "zerolinecolor": "rgb(68, 68, 68)",
            "zerolinewidth": 1
        },
        "height": 500,
        "legend": {
            "x": 0.36035320260418696,
            "y": 1.2830552429388191
        },
        "autosize": false,
        "template": {
            "data": {
                "bar": [
                    {
                        "type": "bar",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "table": [
                    {
                        "type": "table",
                        "cells": {
                            "fill": {
                                "color": "#EBF0F8"
                            },
                            "line": {
                                "color": "white"
                            }
                        },
                        "header": {
                            "fill": {
                                "color": "#C8D4E3"
                            },
                            "line": {
                                "color": "white"
                            }
                        }
                    }
                ],
                "carpet": [
                    {
                        "type": "carpet",
                        "aaxis": {
                            "gridcolor": "#C8D4E3",
                            "linecolor": "#C8D4E3",
                            "endlinecolor": "#2a3f5f",
                            "minorgridcolor": "#C8D4E3",
                            "startlinecolor": "#2a3f5f"
                        },
                        "baxis": {
                            "gridcolor": "#C8D4E3",
                            "linecolor": "#C8D4E3",
                            "endlinecolor": "#2a3f5f",
                            "minorgridcolor": "#C8D4E3",
                            "startlinecolor": "#2a3f5f"
                        }
                    }
                ],
                "mesh3d": [
                    {
                        "type": "mesh3d",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "contour": [
                    {
                        "type": "contour",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ],
                "heatmap": [
                    {
                        "type": "heatmap",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ],
                "scatter": [
                    {
                        "type": "scatter",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "surface": [
                    {
                        "type": "surface",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "heatmapgl": [
                    {
                        "type": "heatmapgl",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "histogram": [
                    {
                        "type": "histogram",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "parcoords": [
                    {
                        "line": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        },
                        "type": "parcoords"
                    }
                ],
                "scatter3d": [
                    {
                        "type": "scatter3d",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scattergl": [
                    {
                        "type": "scattergl",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "choropleth": [
                    {
                        "type": "choropleth",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "scattergeo": [
                    {
                        "type": "scattergeo",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "histogram2d": [
                    {
                        "type": "histogram2d",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ],
                "scatterpolar": [
                    {
                        "type": "scatterpolar",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "contourcarpet": [
                    {
                        "type": "contourcarpet",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "scattercarpet": [
                    {
                        "type": "scattercarpet",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scattermapbox": [
                    {
                        "type": "scattermapbox",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scatterpolargl": [
                    {
                        "type": "scatterpolargl",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scatterternary": [
                    {
                        "type": "scatterternary",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "histogram2dcontour": [
                    {
                        "type": "histogram2dcontour",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ]
            },
            "layout": {
                "geo": {
                    "bgcolor": "white",
                    "showland": true,
                    "lakecolor": "white",
                    "landcolor": "white",
                    "showlakes": true,
                    "subunitcolor": "#C8D4E3"
                },
                "font": {
                    "color": "#2a3f5f"
                },
                "polar": {
                    "bgcolor": "white",
                    "radialaxis": {
                        "ticks": "",
                        "gridcolor": "#EBF0F8",
                        "linecolor": "#EBF0F8"
                    },
                    "angularaxis": {
                        "ticks": "",
                        "gridcolor": "#EBF0F8",
                        "linecolor": "#EBF0F8"
                    }
                },
                "scene": {
                    "xaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "gridwidth": 2,
                        "linecolor": "#EBF0F8",
                        "zerolinecolor": "#EBF0F8",
                        "showbackground": true,
                        "backgroundcolor": "white"
                    },
                    "yaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "gridwidth": 2,
                        "linecolor": "#EBF0F8",
                        "zerolinecolor": "#EBF0F8",
                        "showbackground": true,
                        "backgroundcolor": "white"
                    },
                    "zaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "gridwidth": 2,
                        "linecolor": "#EBF0F8",
                        "zerolinecolor": "#EBF0F8",
                        "showbackground": true,
                        "backgroundcolor": "white"
                    }
                },
                "title": {
                    "x": 0.05
                },
                "xaxis": {
                    "ticks": "",
                    "gridcolor": "#EBF0F8",
                    "linecolor": "#EBF0F8",
                    "automargin": true,
                    "zerolinecolor": "#EBF0F8",
                    "zerolinewidth": 2
                },
                "yaxis": {
                    "ticks": "",
                    "gridcolor": "#EBF0F8",
                    "linecolor": "#EBF0F8",
                    "automargin": true,
                    "zerolinecolor": "#EBF0F8",
                    "zerolinewidth": 2
                },
                "ternary": {
                    "aaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "linecolor": "#A2B1C6"
                    },
                    "baxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "linecolor": "#A2B1C6"
                    },
                    "caxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "linecolor": "#A2B1C6"
                    },
                    "bgcolor": "white"
                },
                "colorway": [
                    "#636efa",
                    "#EF553B",
                    "#00cc96",
                    "#ab63fa",
                    "#19d3f3",
                    "#e763fa",
                    "#fecb52",
                    "#ffa15a",
                    "#ff6692",
                    "#b6e880"
                ],
                "hovermode": "closest",
                "colorscale": {
                    "diverging": [
                        [
                            0,
                            "#8e0152"
                        ],
                        [
                            0.1,
                            "#c51b7d"
                        ],
                        [
                            0.2,
                            "#de77ae"
                        ],
                        [
                            0.3,
                            "#f1b6da"
                        ],
                        [
                            0.4,
                            "#fde0ef"
                        ],
                        [
                            0.5,
                            "#f7f7f7"
                        ],
                        [
                            0.6,
                            "#e6f5d0"
                        ],
                        [
                            0.7,
                            "#b8e186"
                        ],
                        [
                            0.8,
                            "#7fbc41"
                        ],
                        [
                            0.9,
                            "#4d9221"
                        ],
                        [
                            1,
                            "#276419"
                        ]
                    ],
                    "sequential": [
                        [
                            0,
                            "#0508b8"
                        ],
                        [
                            0.0893854748603352,
                            "#1910d8"
                        ],
                        [
                            0.1787709497206704,
                            "#3c19f0"
                        ],
                        [
                            0.2681564245810056,
                            "#6b1cfb"
                        ],
                        [
                            0.3575418994413408,
                            "#981cfd"
                        ],
                        [
                            0.44692737430167595,
                            "#bf1cfd"
                        ],
                        [
                            0.5363128491620112,
                            "#dd2bfd"
                        ],
                        [
                            0.6256983240223464,
                            "#f246fe"
                        ],
                        [
                            0.7150837988826816,
                            "#fc67fd"
                        ],
                        [
                            0.8044692737430168,
                            "#fe88fc"
                        ],
                        [
                            0.8938547486033519,
                            "#fea5fd"
                        ],
                        [
                            0.9832402234636871,
                            "#febefe"
                        ],
                        [
                            1,
                            "#fec3fe"
                        ]
                    ],
                    "sequentialminus": [
                        [
                            0,
                            "#0508b8"
                        ],
                        [
                            0.0893854748603352,
                            "#1910d8"
                        ],
                        [
                            0.1787709497206704,
                            "#3c19f0"
                        ],
                        [
                            0.2681564245810056,
                            "#6b1cfb"
                        ],
                        [
                            0.3575418994413408,
                            "#981cfd"
                        ],
                        [
                            0.44692737430167595,
                            "#bf1cfd"
                        ],
                        [
                            0.5363128491620112,
                            "#dd2bfd"
                        ],
                        [
                            0.6256983240223464,
                            "#f246fe"
                        ],
                        [
                            0.7150837988826816,
                            "#fc67fd"
                        ],
                        [
                            0.8044692737430168,
                            "#fe88fc"
                        ],
                        [
                            0.8938547486033519,
                            "#fea5fd"
                        ],
                        [
                            0.9832402234636871,
                            "#febefe"
                        ],
                        [
                            1,
                            "#fec3fe"
                        ]
                    ]
                },
                "plot_bgcolor": "white",
                "paper_bgcolor": "white",
                "shapedefaults": {
                    "line": {
                        "width": 0
                    },
                    "opacity": 0.4,
                    "fillcolor": "#506784"
                },
                "annotationdefaults": {
                    "arrowhead": 0,
                    "arrowcolor": "#506784",
                    "arrowwidth": 1
                }
            },
            "themeRef": "PLOTLY_WHITE"
        },
        "showlegend": true,
        "annotations": []
    },
    "frames": []
}