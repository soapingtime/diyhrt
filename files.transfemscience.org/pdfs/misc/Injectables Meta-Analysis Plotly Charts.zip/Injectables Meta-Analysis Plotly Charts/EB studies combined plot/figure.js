var figure = {
    "data": [
        {
            "meta": {
                "columnNames": {
                    "x": "G75, x",
                    "y": "G75, y"
                }
            },
            "mode": "lines",
            "name": "Geppert (1975) EB 27.6 mg [n=3]",
            "type": "scatter",
            "xsrc": "transfemscience:0:02b61e",
            "x": [
                "0",
                "0.5",
                "1",
                "1.5",
                "2",
                "3",
                "4",
                "5",
                "6",
                "7",
                "8",
                "9"
            ],
            "ysrc": "transfemscience:0:5523ff",
            "y": [
                "72",
                "2015",
                "2147",
                "1679",
                "1659",
                "1353",
                "1105",
                "1051",
                "835",
                "856",
                "551",
                "625"
            ],
            "visible": true
        },
        {
            "meta": {
                "columnNames": {
                    "x": "K75, x",
                    "y": "K75, y"
                }
            },
            "mode": "lines",
            "name": "Keye (1975) EB ~0.15 mg [n=10]",
            "type": "scatter",
            "xsrc": "transfemscience:0:68bc80",
            "x": [
                "0",
                "0.08333",
                "0.1667",
                "0.25",
                "0.333",
                "0.41667",
                "0.5"
            ],
            "ysrc": "transfemscience:0:d85f2e",
            "y": [
                "0",
                "16.30828262177699",
                "46.64319290197667",
                "45.762335056309325",
                "28.01473383671422",
                "6.658047590393274",
                "0"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "S75a, x",
                    "y": "S75a, y"
                }
            },
            "mode": "lines",
            "name": "Shaw (1975a) EB 1 mg [n=10]",
            "type": "scatter",
            "xsrc": "transfemscience:0:b7279f",
            "x": [
                "0",
                "0.333",
                "1",
                "1.333",
                "2",
                "2.333",
                "3"
            ],
            "ysrc": "transfemscience:0:2284df",
            "y": [
                "81.22747097528884",
                "760.0715310669688",
                "510.36672817409385",
                "377.54483797548033",
                "242.9016008338824",
                "200.19145337155226",
                "149.84523761877983"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "S75b1, x",
                    "y": "S75b1, y"
                }
            },
            "mode": "lines",
            "name": "Shaw (1975b) EB 0.5 mg [n=5]",
            "type": "scatter",
            "xsrc": "transfemscience:0:7c067f",
            "x": [
                "0",
                "0.333",
                "1",
                "1.5",
                "2"
            ],
            "ysrc": "transfemscience:0:ed8eff",
            "y": [
                "100.78997548351948",
                "326.8864069735767",
                "313.53854535548896",
                "228.8204848815037",
                "117.13429583219832"
            ],
            "visible": true
        },
        {
            "meta": {
                "columnNames": {
                    "x": "S75b2, x",
                    "y": "S75b2, y"
                }
            },
            "mode": "lines",
            "name": "Shaw (1975b) EB 1.5 mg [n=5]",
            "type": "scatter",
            "xsrc": "transfemscience:0:be2507",
            "x": [
                "0",
                "0.333",
                "1",
                "1.5",
                "2"
            ],
            "ysrc": "transfemscience:0:65296f",
            "y": [
                "113.32062108417325",
                "742.849359847453",
                "554.0724598202125",
                "394.9877417597385",
                "209.75211114137838"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "S75b3, x",
                    "y": "S75b3, y"
                }
            },
            "mode": "lines",
            "name": "Shaw (1975b) EB 2.5 mg [n=5]",
            "type": "scatter",
            "xsrc": "transfemscience:0:b65041",
            "x": [
                "0",
                "0.333",
                "1",
                "1.5",
                "2"
            ],
            "ysrc": "transfemscience:0:eee1f4",
            "y": [
                "116.04467447561973",
                "676.9272677744484",
                "882.5932988286571",
                "371.56088259329886",
                "292.0185235630619"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "L76, x",
                    "y": "L76, y"
                }
            },
            "mode": "lines",
            "name": "Leyendecker (1976) EB 3 mg [n=3]",
            "type": "scatter",
            "xsrc": "transfemscience:0:222aa9",
            "x": [
                "0",
                "0.125",
                "0.25",
                "0.375",
                "0.5",
                "1",
                "1.05",
                "1.125",
                "1.25",
                "1.375",
                "1.5",
                "1.625",
                "1.875",
                "2",
                "2.125",
                "2.25",
                "2.375"
            ],
            "ysrc": "transfemscience:0:12bb55",
            "y": [
                "186.62054839519988",
                "888.7055322602461",
                "978.2535603176749",
                "1110.1853104287839",
                "1133.9993430078646",
                "1124.7705358350559",
                "1113.4548124673915",
                "1013.356263647079",
                "1050.6734169388028",
                "981.7588065931087",
                "939.8156557361206",
                "1040.9692566327217",
                "850.8511912813274",
                "758.7138412784286",
                "726.4439334505608",
                "574.4043593360504",
                "484.21093312206426"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "C78, x",
                    "y": "C78, y"
                }
            },
            "mode": "lines",
            "name": "Canales (1978) EB 1 mg [n=22]",
            "type": "scatter",
            "xsrc": "transfemscience:0:e77f95",
            "x": [
                "0",
                "1",
                "2",
                "3"
            ],
            "ysrc": "transfemscience:0:533d8f",
            "y": [
                "107.15055695",
                "195.00538987",
                "140.1365433",
                "126.33848365"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "S78, x",
                    "y": "S78, y"
                }
            },
            "mode": "lines",
            "name": "Shaw (1978) EB 2.5 mg [n=6]",
            "type": "scatter",
            "xsrc": "transfemscience:0:db02d7",
            "x": [
                "0",
                "0.333",
                "1",
                "1.333",
                "1.54",
                "2",
                "2.333",
                "3"
            ],
            "ysrc": "transfemscience:0:e08361",
            "y": [
                "91.70115890129443",
                "715.0997914931911",
                "373.18178883525957",
                "281.3338079682061",
                "260.26764364053963",
                "227.0573822884578",
                "105.37790378769034",
                "73.20468872540448"
            ],
            "visible": true
        },
        {
            "meta": {
                "columnNames": {
                    "x": "T78, x",
                    "y": "T78, y"
                }
            },
            "mode": "lines",
            "name": "Travaglini (1978) EB 1 mg [n=19]",
            "type": "scatter",
            "xsrc": "transfemscience:0:0f2b24",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4"
            ],
            "ysrc": "transfemscience:0:5dab60",
            "y": [
                "76.5391014975",
                "366.056572379",
                "213.643926789",
                "134.442595674",
                "89.1846921797"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "T79, x",
                    "y": "T79, y"
                }
            },
            "mode": "lines",
            "name": "Travaglini (1979) EB 1 mg [n=18]",
            "type": "scatter",
            "xsrc": "transfemscience:0:ce771c",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4"
            ],
            "ysrc": "transfemscience:0:0b4916",
            "y": [
                "58.7340011502",
                "377.071324444",
                "232.241555327",
                "140.391328189",
                "91.0393066831"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "O80, x",
                    "y": "O80, y"
                }
            },
            "mode": "lines",
            "name": "Oriowo (1980) EB 5 mg [n=10]",
            "type": "scatter",
            "xsrc": "transfemscience:0:912071",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4",
                "5",
                "6",
                "7",
                "8",
                "9",
                "10",
                "11"
            ],
            "ysrc": "transfemscience:0:16650a",
            "y": [
                "60.49274578105451",
                "339.34492204673825",
                "747.1473502654811",
                "390.53738712841164",
                "170.48158544421517",
                "89.48730088944512",
                "49.37705028915457",
                "32.19757178125792",
                "23.93520240792759",
                "20.80658798065565",
                "21.491088640130556",
                "22.205350197843018"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "C81, x",
                    "y": "C81, y"
                }
            },
            "mode": "lines",
            "name": "Canales (1981) EB 3 mg [n=14]",
            "type": "scatter",
            "xsrc": "transfemscience:0:6ab72d",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4"
            ],
            "ysrc": "transfemscience:0:cbbad1",
            "y": [
                "166.633540858",
                "515.90026346",
                "313.624992667",
                "258.929990093",
                "249.058323358"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "W81, x",
                    "y": "W81, y"
                }
            },
            "mode": "lines",
            "name": "White (1981) EB 1 mg [n=19]",
            "type": "scatter",
            "xsrc": "transfemscience:0:09e029",
            "x": [
                "0",
                "0.5",
                "1",
                "2",
                "3"
            ],
            "ysrc": "transfemscience:0:2e2d89",
            "y": [
                "142.3125",
                "370.47126123672024",
                "230.7273222555162",
                "135.3854535548897",
                "66.73930809043857"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "S82, x",
                    "y": "S82, y"
                }
            },
            "mode": "lines",
            "name": "Schweikert (1982) EB 5 mg [n=2]",
            "type": "scatter",
            "xsrc": "transfemscience:0:3ac246",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4",
                "5",
                "6",
                "7",
                "8"
            ],
            "ysrc": "transfemscience:0:02e873",
            "y": [
                "68.3163727842",
                "725.00240489",
                "1235.53524112",
                "424.5619456",
                "317.432684936",
                "86.4174714547",
                "51.9141468761",
                "31.4448872034",
                "17.9809999096"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "B83, x",
                    "y": "B83, y"
                }
            },
            "mode": "lines",
            "name": "Braun (1983) EB 5 mg [n=10]",
            "type": "scatter",
            "xsrc": "transfemscience:0:d14c17",
            "x": [
                "0",
                "0.5",
                "1",
                "1.5",
                "2",
                "2.5",
                "3",
                "3.5",
                "4",
                "4.5",
                "5",
                "5.5"
            ],
            "ysrc": "transfemscience:0:87826c",
            "y": [
                "167.153086692",
                "1324.47261062",
                "1672.57472238",
                "1508.0274703",
                "815.938690803",
                "919.358627489",
                "527.160115246",
                "464.007046906",
                "400.849592601",
                "318.735979593",
                "289.267121779",
                "324.004404316"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "K84, x",
                    "y": "K84, y"
                }
            },
            "mode": "lines",
            "name": "Kemeter (1984) EB 1 mg [n=17–22]",
            "type": "scatter",
            "xsrc": "transfemscience:0:7fd3ab",
            "x": [
                "0",
                "1",
                "3",
                "5",
                "7",
                "9"
            ],
            "ysrc": "transfemscience:0:09f0f2",
            "y": [
                "67.42563491143545",
                "200.44986117780832",
                "188.17941457329425",
                "95.25189466072743",
                "66.52149674057651",
                "67.42563491143545"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "V84, x",
                    "y": "V84, y"
                }
            },
            "mode": "lines",
            "name": "Välimäki (1984) EB 5 mg [n=7]",
            "type": "scatter",
            "xsrc": "transfemscience:0:dee7b6",
            "x": [
                "0",
                "1",
                "2",
                "3"
            ],
            "ysrc": "transfemscience:0:cd58e5",
            "y": [
                "26.959205880393483",
                "1114.824602311001",
                "618.3518020918925",
                "415.12143486339096"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "G85, x",
                    "y": "G85, y"
                }
            },
            "mode": "lines",
            "name": "Goodman (1985) EB 2 mg [n=10]",
            "type": "scatter",
            "xsrc": "transfemscience:0:0e9f2f",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4",
                "5"
            ],
            "ysrc": "transfemscience:0:395610",
            "y": [
                "40.0800212372",
                "422.40178226",
                "188.948671547",
                "116.856685295",
                "66.1060090536",
                "51.2711959982"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "A86, x",
                    "y": "A86, y"
                }
            },
            "mode": "lines",
            "name": "Aisaka (1986) EB ~5 mg [n=18]",
            "type": "scatter",
            "xsrc": "transfemscience:0:cc4666",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4"
            ],
            "ysrc": "transfemscience:0:3b68fe",
            "y": [
                "145.46518710590772",
                "2984.9332983973663",
                "1875.2309686903386",
                "617.7268257160385",
                "330.26282507176074"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "C86, x",
                    "y": "C86, y"
                }
            },
            "mode": "lines",
            "name": "Cano (1986) EB 2 mg [n=27]",
            "type": "scatter",
            "xsrc": "transfemscience:0:09726c",
            "x": [
                "0",
                "0.333",
                "0.667",
                "1",
                "1.333",
                "1.667",
                "2",
                "2.333",
                "2.667",
                "3"
            ],
            "ysrc": "transfemscience:0:9ce232",
            "y": [
                "156.344988099778",
                "424.448973688017",
                "474.0611973858961",
                "438.9143841470632",
                "394.1947954608214",
                "335.1644334573762",
                "308.37118173808994",
                "242.16860182250912",
                "202.24592039343048",
                "174.2587016265827"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "M87, x",
                    "y": "M87, y"
                }
            },
            "mode": "lines",
            "name": "Messinis (1987) EB 10 mg [n=5]",
            "type": "scatter",
            "xsrc": "transfemscience:0:742411",
            "x": [
                "0",
                "0.25",
                "0.5",
                "0.75",
                "1",
                "1.25",
                "1.5",
                "1.75",
                "2",
                "2.25",
                "2.5",
                "2.75",
                "3",
                "3.25",
                "3.5",
                "3.75",
                "4",
                "4.25",
                "4.5"
            ],
            "ysrc": "transfemscience:0:61fdad",
            "y": [
                "0",
                "2637.369463",
                "3827.206741",
                "4124.533924",
                "3372.028114",
                "3262.590013",
                "2642.822916",
                "1630.488216",
                "1411.551291",
                "936.2869056",
                "790.039401",
                "496.2705321",
                "371.3535487",
                "241.572751",
                "310.0758523",
                "114.8374796",
                "201.0372052",
                "92.24267001",
                "42.57974668"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "S87, x",
                    "y": "S87, y"
                }
            },
            "mode": "lines",
            "name": "Sumioki (1987) EB 1 mg [n=11]",
            "type": "scatter",
            "xsrc": "transfemscience:0:949cf7",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4",
                "5"
            ],
            "ysrc": "transfemscience:0:e3737e",
            "y": [
                "99.5479403375247",
                "322.1546690448149",
                "255.26238282287113",
                "154.143655586039",
                "132.61259692429198",
                "99.12331152607698"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "B89, x",
                    "y": "B89, y"
                }
            },
            "mode": "lines",
            "name": "Bider (1989) EB 2 mg [n=20]",
            "type": "scatter",
            "xsrc": "transfemscience:0:246fb0",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4"
            ],
            "ysrc": "transfemscience:0:e51fbd",
            "y": [
                "64.8870376988",
                "293.326429965",
                "264.226334347",
                "184.968367199",
                "153.466478448"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "V93, x",
                    "y": "V93, y"
                }
            },
            "mode": "lines",
            "name": "Vizziello (1993) EB 2.5 mg [n=21×7]",
            "type": "scatter",
            "xsrc": "transfemscience:0:2f1302",
            "x": [
                "0",
                "1",
                "2"
            ],
            "ysrc": "transfemscience:0:c48746",
            "y": [
                "34.4285714286",
                "477.285714286",
                "365.428571429"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "E06, x",
                    "y": "E06, y"
                }
            },
            "mode": "lines",
            "name": "Eriksson (2006) EB ~2.5 mg [n=25]",
            "type": "scatter",
            "xsrc": "transfemscience:0:202c80",
            "x": [
                "0",
                "0.017",
                "0.25",
                "1",
                "1.333",
                "2",
                "2.333",
                "3",
                "4",
                "5",
                "6"
            ],
            "ysrc": "transfemscience:0:887c96",
            "y": [
                "31.34664381",
                "195.24051789",
                "666.14121813",
                "548.66641563",
                "544.05956063",
                "224.08343615",
                "220.52814588",
                "106.45841011",
                "58.58717772",
                "45.31743234",
                "42.76363228"
            ],
            "visible": true,
            "stackgroup": null
        }
    ],
    "layout": {
        "font": {
            "color": "rgb(68, 68, 68)"
        },
        "width": 725,
        "xaxis": {
            "type": "linear",
            "range": [
                0,
                11
            ],
            "title": {
                "text": "Time (days)"
            },
            "tickmode": "linear",
            "autorange": true,
            "zerolinecolor": "rgb(68, 68, 68)",
            "zerolinewidth": 1
        },
        "yaxis": {
            "type": "linear",
            "range": [
                -229.14077355555557,
                4353.674697555556
            ],
            "title": {
                "text": "Estradiol levels (pg/mL)"
            },
            "autorange": true,
            "zerolinecolor": "rgb(68, 68, 68)",
            "zerolinewidth": 1
        },
        "height": 500,
        "legend": {
            "x": 0.6158199962342309,
            "y": 1.05929203539823
        },
        "autosize": false,
        "template": {
            "data": {
                "bar": [
                    {
                        "type": "bar",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "table": [
                    {
                        "type": "table",
                        "cells": {
                            "fill": {
                                "color": "#EBF0F8"
                            },
                            "line": {
                                "color": "white"
                            }
                        },
                        "header": {
                            "fill": {
                                "color": "#C8D4E3"
                            },
                            "line": {
                                "color": "white"
                            }
                        }
                    }
                ],
                "carpet": [
                    {
                        "type": "carpet",
                        "aaxis": {
                            "gridcolor": "#C8D4E3",
                            "linecolor": "#C8D4E3",
                            "endlinecolor": "#2a3f5f",
                            "minorgridcolor": "#C8D4E3",
                            "startlinecolor": "#2a3f5f"
                        },
                        "baxis": {
                            "gridcolor": "#C8D4E3",
                            "linecolor": "#C8D4E3",
                            "endlinecolor": "#2a3f5f",
                            "minorgridcolor": "#C8D4E3",
                            "startlinecolor": "#2a3f5f"
                        }
                    }
                ],
                "mesh3d": [
                    {
                        "type": "mesh3d",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "contour": [
                    {
                        "type": "contour",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ],
                "heatmap": [
                    {
                        "type": "heatmap",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ],
                "scatter": [
                    {
                        "type": "scatter",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "surface": [
                    {
                        "type": "surface",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "heatmapgl": [
                    {
                        "type": "heatmapgl",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "histogram": [
                    {
                        "type": "histogram",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "parcoords": [
                    {
                        "line": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        },
                        "type": "parcoords"
                    }
                ],
                "scatter3d": [
                    {
                        "type": "scatter3d",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scattergl": [
                    {
                        "type": "scattergl",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "choropleth": [
                    {
                        "type": "choropleth",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "scattergeo": [
                    {
                        "type": "scattergeo",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "histogram2d": [
                    {
                        "type": "histogram2d",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ],
                "scatterpolar": [
                    {
                        "type": "scatterpolar",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "contourcarpet": [
                    {
                        "type": "contourcarpet",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "scattercarpet": [
                    {
                        "type": "scattercarpet",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scattermapbox": [
                    {
                        "type": "scattermapbox",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scatterpolargl": [
                    {
                        "type": "scatterpolargl",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scatterternary": [
                    {
                        "type": "scatterternary",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "histogram2dcontour": [
                    {
                        "type": "histogram2dcontour",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ]
            },
            "layout": {
                "geo": {
                    "bgcolor": "white",
                    "showland": true,
                    "lakecolor": "white",
                    "landcolor": "white",
                    "showlakes": true,
                    "subunitcolor": "#C8D4E3"
                },
                "font": {
                    "color": "#2a3f5f"
                },
                "polar": {
                    "bgcolor": "white",
                    "radialaxis": {
                        "ticks": "",
                        "gridcolor": "#EBF0F8",
                        "linecolor": "#EBF0F8"
                    },
                    "angularaxis": {
                        "ticks": "",
                        "gridcolor": "#EBF0F8",
                        "linecolor": "#EBF0F8"
                    }
                },
                "scene": {
                    "xaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "gridwidth": 2,
                        "linecolor": "#EBF0F8",
                        "zerolinecolor": "#EBF0F8",
                        "showbackground": true,
                        "backgroundcolor": "white"
                    },
                    "yaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "gridwidth": 2,
                        "linecolor": "#EBF0F8",
                        "zerolinecolor": "#EBF0F8",
                        "showbackground": true,
                        "backgroundcolor": "white"
                    },
                    "zaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "gridwidth": 2,
                        "linecolor": "#EBF0F8",
                        "zerolinecolor": "#EBF0F8",
                        "showbackground": true,
                        "backgroundcolor": "white"
                    }
                },
                "title": {
                    "x": 0.05
                },
                "xaxis": {
                    "ticks": "",
                    "gridcolor": "#EBF0F8",
                    "linecolor": "#EBF0F8",
                    "automargin": true,
                    "zerolinecolor": "#EBF0F8",
                    "zerolinewidth": 2
                },
                "yaxis": {
                    "ticks": "",
                    "gridcolor": "#EBF0F8",
                    "linecolor": "#EBF0F8",
                    "automargin": true,
                    "zerolinecolor": "#EBF0F8",
                    "zerolinewidth": 2
                },
                "ternary": {
                    "aaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "linecolor": "#A2B1C6"
                    },
                    "baxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "linecolor": "#A2B1C6"
                    },
                    "caxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "linecolor": "#A2B1C6"
                    },
                    "bgcolor": "white"
                },
                "colorway": [
                    "#636efa",
                    "#EF553B",
                    "#00cc96",
                    "#ab63fa",
                    "#19d3f3",
                    "#e763fa",
                    "#fecb52",
                    "#ffa15a",
                    "#ff6692",
                    "#b6e880"
                ],
                "hovermode": "closest",
                "colorscale": {
                    "diverging": [
                        [
                            0,
                            "#8e0152"
                        ],
                        [
                            0.1,
                            "#c51b7d"
                        ],
                        [
                            0.2,
                            "#de77ae"
                        ],
                        [
                            0.3,
                            "#f1b6da"
                        ],
                        [
                            0.4,
                            "#fde0ef"
                        ],
                        [
                            0.5,
                            "#f7f7f7"
                        ],
                        [
                            0.6,
                            "#e6f5d0"
                        ],
                        [
                            0.7,
                            "#b8e186"
                        ],
                        [
                            0.8,
                            "#7fbc41"
                        ],
                        [
                            0.9,
                            "#4d9221"
                        ],
                        [
                            1,
                            "#276419"
                        ]
                    ],
                    "sequential": [
                        [
                            0,
                            "#0508b8"
                        ],
                        [
                            0.0893854748603352,
                            "#1910d8"
                        ],
                        [
                            0.1787709497206704,
                            "#3c19f0"
                        ],
                        [
                            0.2681564245810056,
                            "#6b1cfb"
                        ],
                        [
                            0.3575418994413408,
                            "#981cfd"
                        ],
                        [
                            0.44692737430167595,
                            "#bf1cfd"
                        ],
                        [
                            0.5363128491620112,
                            "#dd2bfd"
                        ],
                        [
                            0.6256983240223464,
                            "#f246fe"
                        ],
                        [
                            0.7150837988826816,
                            "#fc67fd"
                        ],
                        [
                            0.8044692737430168,
                            "#fe88fc"
                        ],
                        [
                            0.8938547486033519,
                            "#fea5fd"
                        ],
                        [
                            0.9832402234636871,
                            "#febefe"
                        ],
                        [
                            1,
                            "#fec3fe"
                        ]
                    ],
                    "sequentialminus": [
                        [
                            0,
                            "#0508b8"
                        ],
                        [
                            0.0893854748603352,
                            "#1910d8"
                        ],
                        [
                            0.1787709497206704,
                            "#3c19f0"
                        ],
                        [
                            0.2681564245810056,
                            "#6b1cfb"
                        ],
                        [
                            0.3575418994413408,
                            "#981cfd"
                        ],
                        [
                            0.44692737430167595,
                            "#bf1cfd"
                        ],
                        [
                            0.5363128491620112,
                            "#dd2bfd"
                        ],
                        [
                            0.6256983240223464,
                            "#f246fe"
                        ],
                        [
                            0.7150837988826816,
                            "#fc67fd"
                        ],
                        [
                            0.8044692737430168,
                            "#fe88fc"
                        ],
                        [
                            0.8938547486033519,
                            "#fea5fd"
                        ],
                        [
                            0.9832402234636871,
                            "#febefe"
                        ],
                        [
                            1,
                            "#fec3fe"
                        ]
                    ]
                },
                "plot_bgcolor": "white",
                "paper_bgcolor": "white",
                "shapedefaults": {
                    "line": {
                        "width": 0
                    },
                    "opacity": 0.4,
                    "fillcolor": "#506784"
                },
                "annotationdefaults": {
                    "arrowhead": 0,
                    "arrowcolor": "#506784",
                    "arrowwidth": 1
                }
            },
            "themeRef": "PLOTLY_WHITE"
        },
        "annotations": []
    },
    "frames": []
}