var figure = {
    "data": [
        {
            "meta": {
                "columnNames": {
                    "x": "J76, x",
                    "y": "J76, y"
                }
            },
            "mode": "lines",
            "name": "Jönsson (1976) PEP 160 mg [n=16]",
            "type": "scatter",
            "xsrc": "transfemscience:12:248406",
            "x": [
                "0",
                "7.609375",
                "15.21875",
                "30.4375"
            ],
            "ysrc": "transfemscience:12:1ad0ae",
            "y": [
                "37.1225144569",
                "168.635036585",
                "217.425123733",
                "182.430429894"
            ],
            "visible": true
        },
        {
            "meta": {
                "columnNames": {
                    "x": "L79, x",
                    "y": "L79, y"
                }
            },
            "mode": "lines",
            "name": "Leinonen (1979) PEP 80 mg [n=10]",
            "type": "scatter",
            "xsrc": "transfemscience:12:b366e2",
            "x": [
                "0",
                "30"
            ],
            "ysrc": "transfemscience:12:640980",
            "y": [
                "0",
                "1626.986289"
            ],
            "visible": "legendonly",
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "L80, x",
                    "y": "L80, y"
                }
            },
            "mode": "lines",
            "name": "Leinonen (1980) PEP 80 mg [n=4–8]",
            "type": "scatter",
            "xsrc": "transfemscience:12:1f1ea8",
            "x": [
                "0",
                "2",
                "4.5",
                "8"
            ],
            "ysrc": "transfemscience:12:fa21a4",
            "y": [
                "51.03512262737809",
                "198.35006371705185",
                "484.0036665250735",
                "1072.1903015940443"
            ],
            "visible": "legendonly"
        },
        {
            "meta": {
                "columnNames": {
                    "x": "J82, x",
                    "y": "J82, y"
                }
            },
            "mode": "lines",
            "name": "Jacobi (1982) PEP 80 mg [n=4]",
            "type": "scatter",
            "xsrc": "transfemscience:12:1f0162",
            "x": [
                "0",
                "7",
                "14",
                "21",
                "28"
            ],
            "ysrc": "transfemscience:12:31565d",
            "y": [
                "74.44444444444491",
                "788.8888888888891",
                "734.4444444444446",
                "576.6666666666669",
                "457.77777777777794"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "N87-80s, x",
                    "y": "N87-80s, y"
                }
            },
            "mode": "lines",
            "name": "Norlén (1987a) PEP 80 mg [n=4]",
            "type": "scatter",
            "xsrc": "transfemscience:12:ec6e33",
            "x": [
                "0",
                "4",
                "7",
                "14",
                "28"
            ],
            "ysrc": "transfemscience:12:6ceaea",
            "y": [
                "34.856122046748624",
                "177.69409475564635",
                "136.3716420789542",
                "321.2197965328396",
                "249.93919468603463"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "N87-160s, x",
                    "y": "N87-160s, y"
                }
            },
            "mode": "lines",
            "name": "Norlén (1987a) PEP 160 mg [n=4]",
            "type": "scatter",
            "xsrc": "transfemscience:12:9fa32f",
            "x": [
                "0",
                "4",
                "7",
                "14",
                "28"
            ],
            "ysrc": "transfemscience:12:30c8b2",
            "y": [
                "27.81451445206767",
                "125.15699729673452",
                "194.70991890205823",
                "285.47307132459946",
                "294.0320232896652"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "N87-240s, x",
                    "y": "N87-240s, y"
                }
            },
            "mode": "lines",
            "name": "Norlén (1987a) PEP 240 mg [n=4]",
            "type": "scatter",
            "xsrc": "transfemscience:12:5f0c6d",
            "x": [
                "0",
                "4",
                "7",
                "14",
                "28"
            ],
            "ysrc": "transfemscience:12:beca28",
            "y": [
                "27.681660899652343",
                "370.24221453287055",
                "505.19031141868436",
                "795.8477508650508",
                "615.9169550173001"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "N87-80r, x",
                    "y": "N87-80r, y"
                }
            },
            "mode": "lines",
            "name": "Norlén (1987b) PEP 80 mg [n=3]",
            "type": "scatter",
            "xsrc": "transfemscience:12:52aee8",
            "x": [
                "0",
                "15",
                "30"
            ],
            "ysrc": "transfemscience:12:fbc84e",
            "y": [
                "32.81249999999977",
                "295.31249999999955",
                "229.68749999999977"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "N87-160r, x",
                    "y": "N87-160r, y"
                }
            },
            "mode": "lines",
            "name": "Norlén (1987b) PEP 160 mg [n=3]",
            "type": "scatter",
            "xsrc": "transfemscience:12:732622",
            "x": [
                "0",
                "15",
                "30"
            ],
            "ysrc": "transfemscience:12:da71cd",
            "y": [
                "36.92307692307577",
                "267.69230769230717",
                "281.5384615384605"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "N87-240r, x",
                    "y": "N87-240r, y"
                }
            },
            "mode": "lines",
            "name": "Norlén (1987b) PEP 240 mg [n=3]",
            "type": "scatter",
            "xsrc": "transfemscience:12:b0b52a",
            "x": [
                "0",
                "15",
                "30"
            ],
            "ysrc": "transfemscience:12:a8fc7b",
            "y": [
                "26.015326170677326",
                "575.6165063119292",
                "749.2017075495096"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "S88 160, x",
                    "y": "S88 160, y"
                }
            },
            "mode": "lines",
            "name": "Stege (1988) PEP 160 mg [n=9]",
            "type": "scatter",
            "xsrc": "transfemscience:12:857c63",
            "x": [
                "0",
                "1",
                "2",
                "4",
                "7",
                "14",
                "21",
                "28"
            ],
            "ysrc": "transfemscience:12:032c76",
            "y": [
                "18.788424117977797",
                "60.73118903831562",
                "51.05178615436864",
                "66.63214205242616",
                "87.92157142337749",
                "116.13180671243708",
                "114.1867264316171",
                "122.84496216813363"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "S88 240, x",
                    "y": "S88 240, y"
                }
            },
            "mode": "lines",
            "name": "Stege (1988) PEP 240 mg [n=9]",
            "type": "scatter",
            "xsrc": "transfemscience:12:916a84",
            "x": [
                "0",
                "1",
                "2",
                "4",
                "7",
                "14",
                "21",
                "28"
            ],
            "ysrc": "transfemscience:12:7b4a58",
            "y": [
                "20.05141205707787",
                "89.80619650628046",
                "73.75928418951253",
                "89.33964008757016",
                "119.46998503222369",
                "147.68022032128317",
                "153.3130676750643",
                "153.18295757519854"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "S88 320, x",
                    "y": "S88 320, y"
                }
            },
            "mode": "lines",
            "name": "Stege (1988) PEP 320 mg [n=9]",
            "type": "scatter",
            "xsrc": "transfemscience:12:492aa4",
            "x": [
                "0",
                "1",
                "2",
                "4",
                "7",
                "14",
                "21",
                "28"
            ],
            "ysrc": "transfemscience:12:076e62",
            "y": [
                "20.051412057077982",
                "206.0536566408207",
                "143.27619057734466",
                "120.94062343373548",
                "149.78169557062893",
                "202.0149865712525",
                "225.303380203777",
                "211.25411790514897"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "S96, x",
                    "y": "S96, y"
                }
            },
            "mode": "lines",
            "name": "Stege (1996) PEP 320 mg [n=11]",
            "type": "scatter",
            "xsrc": "transfemscience:12:d2e425",
            "x": [
                "0",
                "2",
                "4",
                "7",
                "14",
                "21",
                "28",
                "35",
                "42",
                "56",
                "70",
                "84"
            ],
            "ysrc": "transfemscience:12:653546",
            "y": [
                "18.0333743911",
                "157.468101553",
                "145.659368102",
                "181.749803735",
                "239.203445318",
                "244.983045126",
                "227.539328604",
                "206.984108512",
                "183.099204088",
                "161.32239644",
                "135.359709416",
                "126.088314171"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "H99, x",
                    "y": "H99, y"
                }
            },
            "mode": "lines",
            "name": "Henriksson (1999) PEP 240 mg [n=17]",
            "type": "scatter",
            "xsrc": "transfemscience:12:e50018",
            "x": [
                "0",
                "15"
            ],
            "ysrc": "transfemscience:12:2710c0",
            "y": [
                "23.69926450558431",
                "172.897351811548"
            ],
            "stackgroup": null
        }
    ],
    "layout": {
        "font": {
            "color": "rgb(68, 68, 68)"
        },
        "width": 725,
        "xaxis": {
            "type": "linear",
            "dtick": 7,
            "range": [
                -2,
                86
            ],
            "title": {
                "text": "Time (days)"
            },
            "tickmode": "linear",
            "autorange": false,
            "zerolinecolor": "rgb(68, 68, 68)",
            "zerolinewidth": 1
        },
        "yaxis": {
            "type": "linear",
            "range": [
                -25.17853541300838,
                839.0596606691591
            ],
            "title": {
                "text": "Estradiol levels (pg/mL)"
            },
            "autorange": true,
            "zerolinecolor": "rgb(68, 68, 68)",
            "zerolinewidth": 1
        },
        "height": 500,
        "legend": {
            "x": 0.48450334504014714,
            "y": 1.0909090909090908
        },
        "autosize": false,
        "template": {
            "data": {
                "bar": [
                    {
                        "type": "bar",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "table": [
                    {
                        "type": "table",
                        "cells": {
                            "fill": {
                                "color": "#EBF0F8"
                            },
                            "line": {
                                "color": "white"
                            }
                        },
                        "header": {
                            "fill": {
                                "color": "#C8D4E3"
                            },
                            "line": {
                                "color": "white"
                            }
                        }
                    }
                ],
                "carpet": [
                    {
                        "type": "carpet",
                        "aaxis": {
                            "gridcolor": "#C8D4E3",
                            "linecolor": "#C8D4E3",
                            "endlinecolor": "#2a3f5f",
                            "minorgridcolor": "#C8D4E3",
                            "startlinecolor": "#2a3f5f"
                        },
                        "baxis": {
                            "gridcolor": "#C8D4E3",
                            "linecolor": "#C8D4E3",
                            "endlinecolor": "#2a3f5f",
                            "minorgridcolor": "#C8D4E3",
                            "startlinecolor": "#2a3f5f"
                        }
                    }
                ],
                "mesh3d": [
                    {
                        "type": "mesh3d",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "contour": [
                    {
                        "type": "contour",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ],
                "heatmap": [
                    {
                        "type": "heatmap",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ],
                "scatter": [
                    {
                        "type": "scatter",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "surface": [
                    {
                        "type": "surface",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "heatmapgl": [
                    {
                        "type": "heatmapgl",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "histogram": [
                    {
                        "type": "histogram",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "parcoords": [
                    {
                        "line": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        },
                        "type": "parcoords"
                    }
                ],
                "scatter3d": [
                    {
                        "type": "scatter3d",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scattergl": [
                    {
                        "type": "scattergl",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "choropleth": [
                    {
                        "type": "choropleth",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "scattergeo": [
                    {
                        "type": "scattergeo",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "histogram2d": [
                    {
                        "type": "histogram2d",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ],
                "scatterpolar": [
                    {
                        "type": "scatterpolar",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "contourcarpet": [
                    {
                        "type": "contourcarpet",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "scattercarpet": [
                    {
                        "type": "scattercarpet",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scattermapbox": [
                    {
                        "type": "scattermapbox",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scatterpolargl": [
                    {
                        "type": "scatterpolargl",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scatterternary": [
                    {
                        "type": "scatterternary",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "histogram2dcontour": [
                    {
                        "type": "histogram2dcontour",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ]
            },
            "layout": {
                "geo": {
                    "bgcolor": "white",
                    "showland": true,
                    "lakecolor": "white",
                    "landcolor": "white",
                    "showlakes": true,
                    "subunitcolor": "#C8D4E3"
                },
                "font": {
                    "color": "#2a3f5f"
                },
                "polar": {
                    "bgcolor": "white",
                    "radialaxis": {
                        "ticks": "",
                        "gridcolor": "#EBF0F8",
                        "linecolor": "#EBF0F8"
                    },
                    "angularaxis": {
                        "ticks": "",
                        "gridcolor": "#EBF0F8",
                        "linecolor": "#EBF0F8"
                    }
                },
                "scene": {
                    "xaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "gridwidth": 2,
                        "linecolor": "#EBF0F8",
                        "zerolinecolor": "#EBF0F8",
                        "showbackground": true,
                        "backgroundcolor": "white"
                    },
                    "yaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "gridwidth": 2,
                        "linecolor": "#EBF0F8",
                        "zerolinecolor": "#EBF0F8",
                        "showbackground": true,
                        "backgroundcolor": "white"
                    },
                    "zaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "gridwidth": 2,
                        "linecolor": "#EBF0F8",
                        "zerolinecolor": "#EBF0F8",
                        "showbackground": true,
                        "backgroundcolor": "white"
                    }
                },
                "title": {
                    "x": 0.05
                },
                "xaxis": {
                    "ticks": "",
                    "gridcolor": "#EBF0F8",
                    "linecolor": "#EBF0F8",
                    "automargin": true,
                    "zerolinecolor": "#EBF0F8",
                    "zerolinewidth": 2
                },
                "yaxis": {
                    "ticks": "",
                    "gridcolor": "#EBF0F8",
                    "linecolor": "#EBF0F8",
                    "automargin": true,
                    "zerolinecolor": "#EBF0F8",
                    "zerolinewidth": 2
                },
                "ternary": {
                    "aaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "linecolor": "#A2B1C6"
                    },
                    "baxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "linecolor": "#A2B1C6"
                    },
                    "caxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "linecolor": "#A2B1C6"
                    },
                    "bgcolor": "white"
                },
                "colorway": [
                    "#636efa",
                    "#EF553B",
                    "#00cc96",
                    "#ab63fa",
                    "#19d3f3",
                    "#e763fa",
                    "#fecb52",
                    "#ffa15a",
                    "#ff6692",
                    "#b6e880"
                ],
                "hovermode": "closest",
                "colorscale": {
                    "diverging": [
                        [
                            0,
                            "#8e0152"
                        ],
                        [
                            0.1,
                            "#c51b7d"
                        ],
                        [
                            0.2,
                            "#de77ae"
                        ],
                        [
                            0.3,
                            "#f1b6da"
                        ],
                        [
                            0.4,
                            "#fde0ef"
                        ],
                        [
                            0.5,
                            "#f7f7f7"
                        ],
                        [
                            0.6,
                            "#e6f5d0"
                        ],
                        [
                            0.7,
                            "#b8e186"
                        ],
                        [
                            0.8,
                            "#7fbc41"
                        ],
                        [
                            0.9,
                            "#4d9221"
                        ],
                        [
                            1,
                            "#276419"
                        ]
                    ],
                    "sequential": [
                        [
                            0,
                            "#0508b8"
                        ],
                        [
                            0.0893854748603352,
                            "#1910d8"
                        ],
                        [
                            0.1787709497206704,
                            "#3c19f0"
                        ],
                        [
                            0.2681564245810056,
                            "#6b1cfb"
                        ],
                        [
                            0.3575418994413408,
                            "#981cfd"
                        ],
                        [
                            0.44692737430167595,
                            "#bf1cfd"
                        ],
                        [
                            0.5363128491620112,
                            "#dd2bfd"
                        ],
                        [
                            0.6256983240223464,
                            "#f246fe"
                        ],
                        [
                            0.7150837988826816,
                            "#fc67fd"
                        ],
                        [
                            0.8044692737430168,
                            "#fe88fc"
                        ],
                        [
                            0.8938547486033519,
                            "#fea5fd"
                        ],
                        [
                            0.9832402234636871,
                            "#febefe"
                        ],
                        [
                            1,
                            "#fec3fe"
                        ]
                    ],
                    "sequentialminus": [
                        [
                            0,
                            "#0508b8"
                        ],
                        [
                            0.0893854748603352,
                            "#1910d8"
                        ],
                        [
                            0.1787709497206704,
                            "#3c19f0"
                        ],
                        [
                            0.2681564245810056,
                            "#6b1cfb"
                        ],
                        [
                            0.3575418994413408,
                            "#981cfd"
                        ],
                        [
                            0.44692737430167595,
                            "#bf1cfd"
                        ],
                        [
                            0.5363128491620112,
                            "#dd2bfd"
                        ],
                        [
                            0.6256983240223464,
                            "#f246fe"
                        ],
                        [
                            0.7150837988826816,
                            "#fc67fd"
                        ],
                        [
                            0.8044692737430168,
                            "#fe88fc"
                        ],
                        [
                            0.8938547486033519,
                            "#fea5fd"
                        ],
                        [
                            0.9832402234636871,
                            "#febefe"
                        ],
                        [
                            1,
                            "#fec3fe"
                        ]
                    ]
                },
                "plot_bgcolor": "white",
                "paper_bgcolor": "white",
                "shapedefaults": {
                    "line": {
                        "width": 0
                    },
                    "opacity": 0.4,
                    "fillcolor": "#506784"
                },
                "annotationdefaults": {
                    "arrowhead": 0,
                    "arrowcolor": "#506784",
                    "arrowwidth": 1
                }
            },
            "themeRef": "PLOTLY_WHITE"
        },
        "showlegend": true
    },
    "frames": []
}