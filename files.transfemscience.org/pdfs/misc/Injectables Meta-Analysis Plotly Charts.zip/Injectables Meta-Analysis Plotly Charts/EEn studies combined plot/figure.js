var figure = {
    "data": [
        {
            "meta": {
                "columnNames": {
                    "x": "R86 5, x",
                    "y": "R86 5, y"
                }
            },
            "mode": "lines",
            "name": "Recio (1986) EEn 5 mg [n=1]",
            "type": "scatter",
            "xsrc": "transfemscience:8:c09bd9",
            "x": [
                "2",
                "7",
                "8",
                "9",
                "11",
                "13",
                "17",
                "21",
                "23",
                "25",
                "30",
                "32"
            ],
            "ysrc": "transfemscience:8:70a0dd",
            "y": [
                "129.49208741522227",
                "206.3059532780709",
                "202.18839487565936",
                "227.1710625470987",
                "191.02938960060283",
                "126.97814619442352",
                "65.38357196684251",
                "81.57950263752821",
                "57.908063300678236",
                "66.89977392614918",
                "64.13564431047473",
                "73.12434061793516"
            ]
        },
        {
            "meta": {
                "columnNames": {
                    "x": "R86 10, x",
                    "y": "R86 10, y"
                }
            },
            "mode": "lines",
            "name": "Recio (1986) EEn 10 mg [n=1]",
            "type": "scatter",
            "xsrc": "transfemscience:8:a01770",
            "x": [
                "2",
                "3",
                "5",
                "10",
                "15",
                "17",
                "18",
                "22",
                "24",
                "26",
                "29",
                "31",
                "32"
            ],
            "ysrc": "transfemscience:8:c158a4",
            "y": [
                "47.04598235020899",
                "176.20993961913598",
                "404.3520668834184",
                "174.56107756618667",
                "122.9168601950766",
                "156.60938225731536",
                "139.0292614955875",
                "80.21365536460746",
                "81.89967487227119",
                "93.2419879238272",
                "73.73432419879236",
                "41.60705991639577",
                "28.862052949372924"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "W86, x",
                    "y": "W86, y"
                }
            },
            "mode": "lines",
            "name": "Wiemeyer (1986) EEn 10 mg [n=3]",
            "type": "scatter",
            "xsrc": "transfemscience:8:2bf7d5",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "6",
                "8",
                "10",
                "13",
                "15",
                "17",
                "20",
                "22",
                "24",
                "27",
                "29",
                "31"
            ],
            "ysrc": "transfemscience:8:e01460",
            "y": [
                "18.83",
                "441.67",
                "598.33",
                "850",
                "726.67",
                "413.33",
                "546.67",
                "430",
                "205",
                "401.67",
                "95.67",
                "60.33",
                "53",
                "44",
                "49.33",
                "38.5"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "S88, x",
                    "y": "S88, y"
                }
            },
            "mode": "lines",
            "name": "Schiavon (1988) EEn 10 mg [n=14]",
            "type": "scatter",
            "xsrc": "transfemscience:8:1cb3dc",
            "x": [
                "0",
                "5.25",
                "30"
            ],
            "ysrc": "transfemscience:8:92a2ea",
            "y": [
                "43",
                "289.5",
                "56.5"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "G89, x",
                    "y": "G89, y"
                }
            },
            "mode": "lines",
            "name": "Garza-Flores (1989) EEn 10 mg [n=10]",
            "type": "scatter",
            "xsrc": "transfemscience:8:d4651f",
            "x": [
                "0",
                "10",
                "20",
                "30"
            ],
            "ysrc": "transfemscience:8:7c4d7a",
            "y": [
                "69.70262015753099",
                "267.16605047420006",
                "149.45185661469185",
                "86.32052724642307"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "G94a, x",
                    "y": "G94a, y"
                }
            },
            "mode": "lines",
            "name": "Garza-Flores (1994a) EEn 10 mg [n=9]",
            "type": "scatter",
            "xsrc": "transfemscience:8:a4cc24",
            "x": [
                "0",
                "8.1",
                "30"
            ],
            "ysrc": "transfemscience:8:9597d3",
            "y": [
                "39",
                "317",
                "39"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "G94b, x",
                    "y": "G94b, y"
                }
            },
            "mode": "lines",
            "name": "Garza-Flores (1994b) EEn 5 mg [n=9]",
            "type": "scatter",
            "xsrc": "transfemscience:8:4ef32c",
            "x": [
                "0",
                "6.5"
            ],
            "ysrc": "transfemscience:8:7a7bb8",
            "y": [
                "35",
                "148"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "G94c, x",
                    "y": "G94c, y"
                }
            },
            "mode": "lines",
            "name": "Garza-Flores (1994c) EEn 10 mg [n=7]",
            "type": "scatter",
            "xsrc": "transfemscience:8:304c69",
            "x": [
                "0",
                "4.2",
                "30"
            ],
            "ysrc": "transfemscience:8:887871",
            "y": [
                "29",
                "314",
                "29"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "M95, x",
                    "y": "M95, y"
                }
            },
            "mode": "lines",
            "name": "Martinez (1995) EEn 10 mg [n=216]",
            "type": "scatter",
            "xsrc": "transfemscience:8:17df58",
            "x": [
                "0",
                "7",
                "30"
            ],
            "ysrc": "transfemscience:8:31f37e",
            "y": [
                "109",
                "439",
                "130"
            ],
            "stackgroup": null
        }
    ],
    "layout": {
        "font": {
            "color": "rgb(68, 68, 68)"
        },
        "width": 725,
        "xaxis": {
            "type": "linear",
            "dtick": 2,
            "range": [
                -1,
                33
            ],
            "title": {
                "text": "Time (days)"
            },
            "tickmode": "linear",
            "autorange": false,
            "zerolinecolor": "rgb(68, 68, 68)",
            "zerolinewidth": 1
        },
        "yaxis": {
            "type": "linear",
            "dtick": 100,
            "range": [
                -27.346111111111114,
                896.1761111111111
            ],
            "title": {
                "text": "Estradiol levels (pg/mL)"
            },
            "tickmode": "auto",
            "autorange": true,
            "zerolinecolor": "rgb(68, 68, 68)",
            "zerolinewidth": 1
        },
        "height": 500,
        "legend": {
            "x": 0.5606249999999999,
            "y": 0.9935064935064936
        },
        "autosize": false,
        "template": {
            "data": {
                "bar": [
                    {
                        "type": "bar",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "table": [
                    {
                        "type": "table",
                        "cells": {
                            "fill": {
                                "color": "#EBF0F8"
                            },
                            "line": {
                                "color": "white"
                            }
                        },
                        "header": {
                            "fill": {
                                "color": "#C8D4E3"
                            },
                            "line": {
                                "color": "white"
                            }
                        }
                    }
                ],
                "carpet": [
                    {
                        "type": "carpet",
                        "aaxis": {
                            "gridcolor": "#C8D4E3",
                            "linecolor": "#C8D4E3",
                            "endlinecolor": "#2a3f5f",
                            "minorgridcolor": "#C8D4E3",
                            "startlinecolor": "#2a3f5f"
                        },
                        "baxis": {
                            "gridcolor": "#C8D4E3",
                            "linecolor": "#C8D4E3",
                            "endlinecolor": "#2a3f5f",
                            "minorgridcolor": "#C8D4E3",
                            "startlinecolor": "#2a3f5f"
                        }
                    }
                ],
                "mesh3d": [
                    {
                        "type": "mesh3d",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "contour": [
                    {
                        "type": "contour",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ],
                "heatmap": [
                    {
                        "type": "heatmap",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ],
                "scatter": [
                    {
                        "type": "scatter",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "surface": [
                    {
                        "type": "surface",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "heatmapgl": [
                    {
                        "type": "heatmapgl",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "histogram": [
                    {
                        "type": "histogram",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "parcoords": [
                    {
                        "line": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        },
                        "type": "parcoords"
                    }
                ],
                "scatter3d": [
                    {
                        "type": "scatter3d",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scattergl": [
                    {
                        "type": "scattergl",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "choropleth": [
                    {
                        "type": "choropleth",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "scattergeo": [
                    {
                        "type": "scattergeo",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "histogram2d": [
                    {
                        "type": "histogram2d",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ],
                "scatterpolar": [
                    {
                        "type": "scatterpolar",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "contourcarpet": [
                    {
                        "type": "contourcarpet",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "scattercarpet": [
                    {
                        "type": "scattercarpet",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scattermapbox": [
                    {
                        "type": "scattermapbox",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scatterpolargl": [
                    {
                        "type": "scatterpolargl",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scatterternary": [
                    {
                        "type": "scatterternary",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "histogram2dcontour": [
                    {
                        "type": "histogram2dcontour",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ]
            },
            "layout": {
                "geo": {
                    "bgcolor": "white",
                    "showland": true,
                    "lakecolor": "white",
                    "landcolor": "white",
                    "showlakes": true,
                    "subunitcolor": "#C8D4E3"
                },
                "font": {
                    "color": "#2a3f5f"
                },
                "polar": {
                    "bgcolor": "white",
                    "radialaxis": {
                        "ticks": "",
                        "gridcolor": "#EBF0F8",
                        "linecolor": "#EBF0F8"
                    },
                    "angularaxis": {
                        "ticks": "",
                        "gridcolor": "#EBF0F8",
                        "linecolor": "#EBF0F8"
                    }
                },
                "scene": {
                    "xaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "gridwidth": 2,
                        "linecolor": "#EBF0F8",
                        "zerolinecolor": "#EBF0F8",
                        "showbackground": true,
                        "backgroundcolor": "white"
                    },
                    "yaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "gridwidth": 2,
                        "linecolor": "#EBF0F8",
                        "zerolinecolor": "#EBF0F8",
                        "showbackground": true,
                        "backgroundcolor": "white"
                    },
                    "zaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "gridwidth": 2,
                        "linecolor": "#EBF0F8",
                        "zerolinecolor": "#EBF0F8",
                        "showbackground": true,
                        "backgroundcolor": "white"
                    }
                },
                "title": {
                    "x": 0.05
                },
                "xaxis": {
                    "ticks": "",
                    "gridcolor": "#EBF0F8",
                    "linecolor": "#EBF0F8",
                    "automargin": true,
                    "zerolinecolor": "#EBF0F8",
                    "zerolinewidth": 2
                },
                "yaxis": {
                    "ticks": "",
                    "gridcolor": "#EBF0F8",
                    "linecolor": "#EBF0F8",
                    "automargin": true,
                    "zerolinecolor": "#EBF0F8",
                    "zerolinewidth": 2
                },
                "ternary": {
                    "aaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "linecolor": "#A2B1C6"
                    },
                    "baxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "linecolor": "#A2B1C6"
                    },
                    "caxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "linecolor": "#A2B1C6"
                    },
                    "bgcolor": "white"
                },
                "colorway": [
                    "#636efa",
                    "#EF553B",
                    "#00cc96",
                    "#ab63fa",
                    "#19d3f3",
                    "#e763fa",
                    "#fecb52",
                    "#ffa15a",
                    "#ff6692",
                    "#b6e880"
                ],
                "hovermode": "closest",
                "colorscale": {
                    "diverging": [
                        [
                            0,
                            "#8e0152"
                        ],
                        [
                            0.1,
                            "#c51b7d"
                        ],
                        [
                            0.2,
                            "#de77ae"
                        ],
                        [
                            0.3,
                            "#f1b6da"
                        ],
                        [
                            0.4,
                            "#fde0ef"
                        ],
                        [
                            0.5,
                            "#f7f7f7"
                        ],
                        [
                            0.6,
                            "#e6f5d0"
                        ],
                        [
                            0.7,
                            "#b8e186"
                        ],
                        [
                            0.8,
                            "#7fbc41"
                        ],
                        [
                            0.9,
                            "#4d9221"
                        ],
                        [
                            1,
                            "#276419"
                        ]
                    ],
                    "sequential": [
                        [
                            0,
                            "#0508b8"
                        ],
                        [
                            0.0893854748603352,
                            "#1910d8"
                        ],
                        [
                            0.1787709497206704,
                            "#3c19f0"
                        ],
                        [
                            0.2681564245810056,
                            "#6b1cfb"
                        ],
                        [
                            0.3575418994413408,
                            "#981cfd"
                        ],
                        [
                            0.44692737430167595,
                            "#bf1cfd"
                        ],
                        [
                            0.5363128491620112,
                            "#dd2bfd"
                        ],
                        [
                            0.6256983240223464,
                            "#f246fe"
                        ],
                        [
                            0.7150837988826816,
                            "#fc67fd"
                        ],
                        [
                            0.8044692737430168,
                            "#fe88fc"
                        ],
                        [
                            0.8938547486033519,
                            "#fea5fd"
                        ],
                        [
                            0.9832402234636871,
                            "#febefe"
                        ],
                        [
                            1,
                            "#fec3fe"
                        ]
                    ],
                    "sequentialminus": [
                        [
                            0,
                            "#0508b8"
                        ],
                        [
                            0.0893854748603352,
                            "#1910d8"
                        ],
                        [
                            0.1787709497206704,
                            "#3c19f0"
                        ],
                        [
                            0.2681564245810056,
                            "#6b1cfb"
                        ],
                        [
                            0.3575418994413408,
                            "#981cfd"
                        ],
                        [
                            0.44692737430167595,
                            "#bf1cfd"
                        ],
                        [
                            0.5363128491620112,
                            "#dd2bfd"
                        ],
                        [
                            0.6256983240223464,
                            "#f246fe"
                        ],
                        [
                            0.7150837988826816,
                            "#fc67fd"
                        ],
                        [
                            0.8044692737430168,
                            "#fe88fc"
                        ],
                        [
                            0.8938547486033519,
                            "#fea5fd"
                        ],
                        [
                            0.9832402234636871,
                            "#febefe"
                        ],
                        [
                            1,
                            "#fec3fe"
                        ]
                    ]
                },
                "plot_bgcolor": "white",
                "paper_bgcolor": "white",
                "shapedefaults": {
                    "line": {
                        "width": 0
                    },
                    "opacity": 0.4,
                    "fillcolor": "#506784"
                },
                "annotationdefaults": {
                    "arrowhead": 0,
                    "arrowcolor": "#506784",
                    "arrowwidth": 1
                }
            },
            "themeRef": "PLOTLY_WHITE"
        }
    },
    "frames": []
}