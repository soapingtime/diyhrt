var figure = {
    "data": [
        {
            "meta": {
                "columnNames": {
                    "x": "S7175, x",
                    "y": "S7175, y"
                }
            },
            "mode": "lines",
            "name": "Somerville (1971–1975) EV 5–20 mg [n=12]",
            "type": "scatter",
            "xsrc": "transfemscience:2:54dd9b",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4",
                "5",
                "6",
                "7",
                "8",
                "9",
                "10",
                "11",
                "12",
                "13",
                "14"
            ],
            "ysrc": "transfemscience:2:4078e5",
            "y": [
                "111.936054",
                "1137.517702",
                "949.486224",
                "916.4236186",
                "521.7031437",
                "334.1645014",
                "308.025142",
                "205.1310102",
                "131.3942937",
                "98.9797435",
                "42.71769539",
                "28.28809994",
                "27.35608233",
                "18",
                "33.34593502"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "G75, x",
                    "y": "G75, y"
                }
            },
            "mode": "lines",
            "name": "Geppert (1975) EV 26.2 mg [n=3]",
            "type": "scatter",
            "xsrc": "transfemscience:2:af8d3c",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4",
                "5",
                "6",
                "7",
                "8",
                "9",
                "10",
                "11"
            ],
            "ysrc": "transfemscience:2:0a731d",
            "y": [
                "26",
                "989",
                "1599",
                "1311",
                "1339",
                "1186",
                "1031",
                "839",
                "557",
                "532",
                "659",
                "431"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "V75a, x",
                    "y": "V75a, y"
                }
            },
            "mode": "lines",
            "name": "Vermeulen (1975a) EV 10 mg [n=4]",
            "type": "scatter",
            "xsrc": "transfemscience:2:0710fa",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4",
                "5",
                "6",
                "7",
                "8",
                "9",
                "10",
                "11",
                "12",
                "13",
                "14"
            ],
            "ysrc": "transfemscience:2:da47d6",
            "y": [
                "23.339827046835353",
                "1241.6930680653008",
                "938.5956686071745",
                "816.3001364238543",
                "475.90954361790864",
                "428.4863262281842",
                "243.79039057167802",
                "205.72110667226116",
                "139.5083285596486",
                "110.9155187639492",
                "75.92336582349776",
                "53.36227733231999",
                "37.15968511475671",
                "27.111354815125196",
                "26.607088453336246"
            ],
            "visible": true
        },
        {
            "meta": {
                "columnNames": {
                    "x": "V75b, x",
                    "y": "V75b, y"
                }
            },
            "mode": "lines",
            "name": "Vermeulen (1975b) EV 4 mg [n=2]",
            "type": "scatter",
            "xsrc": "transfemscience:2:43746b",
            "x": [
                "0",
                "1",
                "2",
                "4",
                "5",
                "6",
                "7",
                "8",
                "9",
                "12",
                "14",
                "15"
            ],
            "ysrc": "transfemscience:2:637cd7",
            "y": [
                "20.087013104930065",
                "378.4138645924758",
                "358.90809902847957",
                "218.49845646318192",
                "127.98500348052403",
                "84.36805786749784",
                "58.58577222239029",
                "42.71163100390413",
                "34.10278139281485",
                "19.178596289458483",
                "16.824475651463274",
                "14.821736630247187"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "O80, x",
                    "y": "O80, y"
                }
            },
            "mode": "lines",
            "name": "Oriowo (1980) EV 5 mg [n=9]",
            "type": "scatter",
            "xsrc": "transfemscience:2:65484c",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4",
                "5",
                "6",
                "7",
                "8",
                "9",
                "10",
                "11",
                "12",
                "13"
            ],
            "ysrc": "transfemscience:2:f3f18b",
            "y": [
                "45.726142292060786",
                "165.46370437201654",
                "610.5701957737597",
                "511.71321880129835",
                "304.8214561691502",
                "213.4934359192846",
                "117.14889582263027",
                "84.87149605904551",
                "53.85449168577611",
                "39.155796148014815",
                "30.750723657005437",
                "24.849734136978668",
                "21.477889302407448",
                "19.34973204850303"
            ],
            "visible": true
        },
        {
            "meta": {
                "columnNames": {
                    "x": "R80, x",
                    "y": "R80, y"
                }
            },
            "mode": "lines",
            "name": "Rauramo (1980) EV 10 mg [n=6]",
            "type": "scatter",
            "xsrc": "transfemscience:2:1e84e9",
            "x": [
                "0",
                "1",
                "10",
                "25",
                "35"
            ],
            "ysrc": "transfemscience:2:f5a939",
            "y": [
                "8.17",
                "1253.06",
                "76.27",
                "16.34",
                "10.9"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "B82, x",
                    "y": "B82, y"
                }
            },
            "mode": "lines",
            "name": "Blackwell (1982) EV 20 mg [n=10]",
            "type": "scatter",
            "xsrc": "transfemscience:2:71f8cf",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4",
                "5",
                "6",
                "7",
                "8",
                "9",
                "10",
                "11",
                "12"
            ],
            "ysrc": "transfemscience:2:992cc7",
            "y": [
                "206.7329483",
                "607.6649152",
                "686.8304278",
                "763.761601",
                "945.2371877",
                "889.9643237",
                "703.705048",
                "744.2292381",
                "813.0242211",
                "619.4453011",
                "668.7141221",
                "542.3508101",
                "442.9954552"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "D83, x",
                    "y": "D83, y"
                }
            },
            "mode": "lines",
            "name": "Düsterberg (1983) EV 4 mg [n=3]",
            "type": "scatter",
            "xsrc": "transfemscience:2:58a40f",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4",
                "7",
                "8",
                "9",
                "10",
                "11",
                "14",
                "16",
                "18"
            ],
            "ysrc": "transfemscience:2:c1f3ee",
            "y": [
                "0",
                "399.919279252",
                "281.750883474",
                "283.980951795",
                "284.612370928",
                "260.679142121",
                "204.296014965",
                "186.058959254",
                "160.100617151",
                "152.365141565",
                "84.7248597043",
                "51.0188235424",
                "67.3702930305044"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "A85, x",
                    "y": "A85, y"
                }
            },
            "mode": "lines",
            "name": "Aedo (1985) EV 5 mg [n=7]",
            "type": "scatter",
            "xsrc": "transfemscience:2:e43383",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4",
                "5",
                "6",
                "7",
                "8",
                "9",
                "10",
                "11",
                "12",
                "13",
                "14",
                "15",
                "16",
                "17",
                "18",
                "19",
                "20",
                "21",
                "22",
                "23",
                "24",
                "25",
                "26",
                "27",
                "28",
                "29",
                "30"
            ],
            "ysrc": "transfemscience:2:340bce",
            "y": [
                "0",
                "229.7092064",
                "618.9575312",
                "397.9705816",
                "356.2497543",
                "274.5313209",
                "180.7499797",
                "153.9878842",
                "115.5451661",
                "95.23566797",
                "94.01824689",
                "90.48538421",
                "81.91053197",
                "46.69845318",
                "76.55426845",
                "39.55968525",
                "25.24119855",
                "38.29900731",
                "28.83601452",
                "36.60657568",
                "44.73744782",
                "25.19814291",
                "44.32721853",
                "41.52158779",
                "52.62126584",
                "85.01160838",
                "49.35734524",
                "51.03233125",
                "25.08442252",
                "83.53418481",
                "49.45687731"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "D85, x",
                    "y": "D85, y"
                }
            },
            "mode": "lines",
            "name": "Düsterberg (1985) EV 4 mg [n=2]",
            "type": "scatter",
            "xsrc": "transfemscience:2:3ac66c",
            "x": [
                "0",
                "1",
                "3",
                "5",
                "7",
                "8",
                "10",
                "12",
                "15",
                "17",
                "19",
                "22"
            ],
            "ysrc": "transfemscience:2:c1d745",
            "y": [
                "26.15831327",
                "206.7623396",
                "301.1473561",
                "555.6733145",
                "225.8122965",
                "163.6783455",
                "147.635947",
                "83.53029718",
                "48.94287019",
                "88.64052237",
                "43.90363156",
                "32.08781646"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "R87, x",
                    "y": "R87, y"
                }
            },
            "mode": "lines",
            "name": "Reimann (1987) EV 10 mg [n=7]",
            "type": "scatter",
            "xsrc": "transfemscience:2:b37638",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4",
                "7",
                "9",
                "11",
                "14",
                "18",
                "21",
                "25"
            ],
            "ysrc": "transfemscience:2:5ab6c2",
            "y": [
                "20.107069514453542",
                "874.9358777059607",
                "658.2555035849617",
                "447.4298102652855",
                "332.7413058578762",
                "96.51561556561342",
                "59.38607423553617",
                "37.49619470976336",
                "27.524231920036073",
                "21.27766929547056",
                "24.210896332961283",
                "22.65009662493867"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "S87a, x",
                    "y": "S87a, y"
                }
            },
            "mode": "lines",
            "name": "Sang et al. (1987) EV 5 mg [n=8]",
            "type": "scatter",
            "xsrc": "transfemscience:2:6e726d",
            "x": [
                "0",
                "1",
                "3",
                "5",
                "7",
                "9",
                "11",
                "13",
                "15",
                "17",
                "19",
                "21",
                "23",
                "25",
                "27",
                "29",
                "31"
            ],
            "ysrc": "transfemscience:2:b66af2",
            "y": [
                "35.55263347",
                "392.703087",
                "330.4445564",
                "189.3588114",
                "139.9041866",
                "127.6349934",
                "85.04678541",
                "57.14572047",
                "49.82903764",
                "46.03337169",
                "30.01301663",
                "28.81501812",
                "20.18568352",
                "18.10513895",
                "26.93081648",
                "29.55840192",
                "36.15165824"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "S87b, x",
                    "y": "S87b, y"
                }
            },
            "mode": "lines",
            "name": "Sang et al. (1987) EV 2.5 mg [n=8]",
            "type": "scatter",
            "xsrc": "transfemscience:2:fd78c1",
            "x": [
                "0",
                "1",
                "3",
                "5",
                "7",
                "9",
                "11",
                "13",
                "15",
                "17",
                "19",
                "21",
                "23",
                "25",
                "27",
                "29",
                "30",
                "31"
            ],
            "ysrc": "transfemscience:2:441f3d",
            "y": [
                "56.13220063",
                "226.431143",
                "241.6812369",
                "174.9917021",
                "118.9270525",
                "97.33697094",
                "62.06042689",
                "38.27719289",
                "42.03306993",
                "35.76222356",
                "30.97250727",
                "43.16351541",
                "35.33046199",
                "41.66547726",
                "50.40289036",
                "62.26343953",
                "32.61629862",
                "76.63279578"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "S87c, x",
                    "y": "S87c, y"
                }
            },
            "mode": "lines",
            "name": "Sherwin (1987) EV 10 mg [n=20]",
            "type": "scatter",
            "xsrc": "transfemscience:2:94f443",
            "x": [
                "0",
                "2",
                "4",
                "8",
                "15",
                "21",
                "28"
            ],
            "ysrc": "transfemscience:2:065cf0",
            "y": [
                "33.0",
                "363.8",
                "354.3",
                "270.5",
                "175.3",
                "116.6",
                "66.9"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "G88, x",
                    "y": "G88, y"
                }
            },
            "mode": "lines",
            "name": "Goh & Ratnam (1988) EV 10 mg [n=54]",
            "type": "scatter",
            "xsrc": "transfemscience:2:44773e",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4",
                "5"
            ],
            "ysrc": "transfemscience:2:43a1ed",
            "y": [
                "88.43408974",
                "467.5670472610502",
                "912.71433105",
                "606.1481241850431",
                "531.76035395",
                "539.1995014498043"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "GR90, x",
                    "y": "GR90, y"
                }
            },
            "mode": "lines",
            "name": "Goh & Ratnamn (1990) EV 10 mg [n=12]",
            "type": "scatter",
            "xsrc": "transfemscience:2:bb5891",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4",
                "5"
            ],
            "ysrc": "transfemscience:2:4e6200",
            "y": [
                "64.15723167782039",
                "466.91665059132515",
                "669.8544316006587",
                "696.8963214672581",
                "685.6387351426746",
                "593.0269620572477"
            ],
            "visible": true
        },
        {
            "meta": {
                "columnNames": {
                    "x": "G85a, x",
                    "y": "G85a, y"
                }
            },
            "mode": "lines",
            "name": "Garza-Flores (1994a) EV 5 mg [n=8]",
            "type": "scatter",
            "xsrc": "transfemscience:2:c48ce1",
            "x": [
                "0",
                "2"
            ],
            "ysrc": "transfemscience:2:c57091",
            "y": [
                "40",
                "415"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "G85b, x",
                    "y": "G85b, y"
                }
            },
            "mode": "lines",
            "name": "Garza-Flores (1994b) EV 5 mg [n=8]",
            "type": "scatter",
            "xsrc": "transfemscience:2:c78835",
            "x": [
                "0",
                "2"
            ],
            "ysrc": "transfemscience:2:be1ddc",
            "y": [
                "40",
                "414"
            ],
            "visible": "legendonly",
            "showlegend": false,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "G85c, x",
                    "y": "G85c, y"
                }
            },
            "mode": "lines",
            "name": "Garza-Flores (1994c) EV 5 mg [n=5]",
            "type": "scatter",
            "xsrc": "transfemscience:2:a37dba",
            "x": [
                "0",
                "2"
            ],
            "ysrc": "transfemscience:2:b43e8a",
            "y": [
                "40",
                "232"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "J94, x",
                    "y": "J94, y"
                }
            },
            "mode": "lines",
            "name": "Jilma (1994) EV 10 mg [n=9]",
            "type": "scatter",
            "xsrc": "transfemscience:2:f543bc",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4",
                "7",
                "11",
                "23"
            ],
            "ysrc": "transfemscience:2:4c625b",
            "y": [
                "10.132367519546863",
                "344.5036838753199",
                "223.6785307054365",
                "159.29165081307897",
                "94.29535090088186",
                "27.66219025508557",
                "11.120728763111892",
                "9.831500493999428"
            ],
            "visible": true
        },
        {
            "meta": {
                "columnNames": {
                    "x": "GL98, x",
                    "y": "GL98, y"
                }
            },
            "mode": "lines",
            "name": "Goh & Lee (1998) EV 10 mg [n=5]",
            "type": "scatter",
            "xsrc": "transfemscience:2:0cebaf",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4",
                "5"
            ],
            "ysrc": "transfemscience:2:3e12f5",
            "y": [
                "45",
                "463",
                "743",
                "589",
                "451",
                "423"
            ],
            "visible": true
        },
        {
            "meta": {
                "columnNames": {
                    "x": "G02, x",
                    "y": "G02, y"
                }
            },
            "mode": "lines",
            "name": "Göretzlehner (2002) EV 5 mg [n=17]",
            "type": "scatter",
            "xsrc": "transfemscience:2:891c81",
            "x": [
                "0",
                "0.1667",
                "3",
                "5",
                "7",
                "9",
                "11"
            ],
            "ysrc": "transfemscience:2:c1b749",
            "y": [
                "14",
                "43.4",
                "244",
                "272",
                "169",
                "115",
                "71"
            ]
        },
        {
            "meta": {
                "columnNames": {
                    "x": "K06, x",
                    "y": "K06, y"
                }
            },
            "mode": "lines",
            "name": "Kerdelhué (2006) EV 2 mg [n=10]",
            "type": "scatter",
            "xsrc": "transfemscience:2:816806",
            "x": [
                "0",
                "0.0208333",
                "0.0416667",
                "0.0833333",
                "0.1666667",
                "0.3333333"
            ],
            "ysrc": "transfemscience:2:9208c4",
            "y": [
                "26.37867647",
                "49.54044118",
                "93.29044118",
                "126.1029412",
                "198.1617647",
                "297.8860294"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "VA11, x",
                    "y": "VA11, y"
                }
            },
            "mode": "lines",
            "name": "Valle Alvarez (2011) EV 5 mg [n=32]",
            "type": "scatter",
            "xsrc": "transfemscience:2:cb1744",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4",
                "5",
                "6",
                "7",
                "10",
                "14",
                "18",
                "22",
                "26",
                "30"
            ],
            "ysrc": "transfemscience:2:7b5449",
            "y": [
                "26.16",
                "281.25",
                "289.62",
                "305.02",
                "243.74",
                "184.65",
                "155.42",
                "115.26",
                "62.42",
                "30.89",
                "17.49",
                "15.31",
                "19.87",
                "27.27"
            ],
            "visible": true
        },
        {
            "meta": {
                "columnNames": {
                    "x": "S12, x",
                    "y": "S12, y"
                }
            },
            "mode": "lines",
            "name": "Schug (2012) EV 10 mg [n=48]",
            "type": "scatter",
            "xsrc": "transfemscience:2:71b626",
            "x": [
                "0",
                "0.0375",
                "0.13",
                "0.145",
                "0.275",
                "0.44",
                "0.68",
                "1",
                "1.5",
                "2",
                "2.5",
                "3",
                "4",
                "5",
                "6",
                "8",
                "10",
                "12",
                "14"
            ],
            "ysrc": "transfemscience:2:b155a3",
            "y": [
                "10.8886107635",
                "25.15644556",
                "43.17897372",
                "54.44305382",
                "80.35043805",
                "127.6595745",
                "185.106383",
                "286.8585732",
                "422.0275344",
                "428.4105131",
                "516.6458073",
                "452.81602",
                "432.5406758",
                "365.3316646",
                "324.4055069",
                "219.2740926",
                "152.81602",
                "107.008761",
                "76.97121402"
            ],
            "visible": true
        }
    ],
    "layout": {
        "font": {
            "color": "rgb(68, 68, 68)"
        },
        "width": 725,
        "xaxis": {
            "type": "linear",
            "dtick": 2,
            "range": [
                -0.5,
                31
            ],
            "title": {
                "text": "Time (days)"
            },
            "tickmode": "linear",
            "autorange": false,
            "zerolinecolor": "rgb(68, 68, 68)",
            "zerolinewidth": 1
        },
        "yaxis": {
            "type": "linear",
            "range": [
                -25,
                1700
            ],
            "title": {
                "text": "Estradiol levels (pg/mL)"
            },
            "autorange": false,
            "zerolinecolor": "rgb(68, 68, 68)",
            "zerolinewidth": 1
        },
        "height": 500,
        "legend": {
            "x": 0.4388570907520351,
            "y": 1.014148835641157
        },
        "autosize": false,
        "template": {
            "data": {
                "bar": [
                    {
                        "type": "bar",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "table": [
                    {
                        "type": "table",
                        "cells": {
                            "fill": {
                                "color": "#EBF0F8"
                            },
                            "line": {
                                "color": "white"
                            }
                        },
                        "header": {
                            "fill": {
                                "color": "#C8D4E3"
                            },
                            "line": {
                                "color": "white"
                            }
                        }
                    }
                ],
                "carpet": [
                    {
                        "type": "carpet",
                        "aaxis": {
                            "gridcolor": "#C8D4E3",
                            "linecolor": "#C8D4E3",
                            "endlinecolor": "#2a3f5f",
                            "minorgridcolor": "#C8D4E3",
                            "startlinecolor": "#2a3f5f"
                        },
                        "baxis": {
                            "gridcolor": "#C8D4E3",
                            "linecolor": "#C8D4E3",
                            "endlinecolor": "#2a3f5f",
                            "minorgridcolor": "#C8D4E3",
                            "startlinecolor": "#2a3f5f"
                        }
                    }
                ],
                "mesh3d": [
                    {
                        "type": "mesh3d",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "contour": [
                    {
                        "type": "contour",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ],
                "heatmap": [
                    {
                        "type": "heatmap",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ],
                "scatter": [
                    {
                        "type": "scatter",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "surface": [
                    {
                        "type": "surface",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "heatmapgl": [
                    {
                        "type": "heatmapgl",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "histogram": [
                    {
                        "type": "histogram",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "parcoords": [
                    {
                        "line": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        },
                        "type": "parcoords"
                    }
                ],
                "scatter3d": [
                    {
                        "type": "scatter3d",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scattergl": [
                    {
                        "type": "scattergl",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "choropleth": [
                    {
                        "type": "choropleth",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "scattergeo": [
                    {
                        "type": "scattergeo",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "histogram2d": [
                    {
                        "type": "histogram2d",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ],
                "scatterpolar": [
                    {
                        "type": "scatterpolar",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "contourcarpet": [
                    {
                        "type": "contourcarpet",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "scattercarpet": [
                    {
                        "type": "scattercarpet",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scattermapbox": [
                    {
                        "type": "scattermapbox",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scatterpolargl": [
                    {
                        "type": "scatterpolargl",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scatterternary": [
                    {
                        "type": "scatterternary",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "histogram2dcontour": [
                    {
                        "type": "histogram2dcontour",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ]
            },
            "layout": {
                "geo": {
                    "bgcolor": "white",
                    "showland": true,
                    "lakecolor": "white",
                    "landcolor": "white",
                    "showlakes": true,
                    "subunitcolor": "#C8D4E3"
                },
                "font": {
                    "color": "#2a3f5f"
                },
                "polar": {
                    "bgcolor": "white",
                    "radialaxis": {
                        "ticks": "",
                        "gridcolor": "#EBF0F8",
                        "linecolor": "#EBF0F8"
                    },
                    "angularaxis": {
                        "ticks": "",
                        "gridcolor": "#EBF0F8",
                        "linecolor": "#EBF0F8"
                    }
                },
                "scene": {
                    "xaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "gridwidth": 2,
                        "linecolor": "#EBF0F8",
                        "zerolinecolor": "#EBF0F8",
                        "showbackground": true,
                        "backgroundcolor": "white"
                    },
                    "yaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "gridwidth": 2,
                        "linecolor": "#EBF0F8",
                        "zerolinecolor": "#EBF0F8",
                        "showbackground": true,
                        "backgroundcolor": "white"
                    },
                    "zaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "gridwidth": 2,
                        "linecolor": "#EBF0F8",
                        "zerolinecolor": "#EBF0F8",
                        "showbackground": true,
                        "backgroundcolor": "white"
                    }
                },
                "title": {
                    "x": 0.05
                },
                "xaxis": {
                    "ticks": "",
                    "gridcolor": "#EBF0F8",
                    "linecolor": "#EBF0F8",
                    "automargin": true,
                    "zerolinecolor": "#EBF0F8",
                    "zerolinewidth": 2
                },
                "yaxis": {
                    "ticks": "",
                    "gridcolor": "#EBF0F8",
                    "linecolor": "#EBF0F8",
                    "automargin": true,
                    "zerolinecolor": "#EBF0F8",
                    "zerolinewidth": 2
                },
                "ternary": {
                    "aaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "linecolor": "#A2B1C6"
                    },
                    "baxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "linecolor": "#A2B1C6"
                    },
                    "caxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "linecolor": "#A2B1C6"
                    },
                    "bgcolor": "white"
                },
                "colorway": [
                    "#636efa",
                    "#EF553B",
                    "#00cc96",
                    "#ab63fa",
                    "#19d3f3",
                    "#e763fa",
                    "#fecb52",
                    "#ffa15a",
                    "#ff6692",
                    "#b6e880"
                ],
                "hovermode": "closest",
                "colorscale": {
                    "diverging": [
                        [
                            0,
                            "#8e0152"
                        ],
                        [
                            0.1,
                            "#c51b7d"
                        ],
                        [
                            0.2,
                            "#de77ae"
                        ],
                        [
                            0.3,
                            "#f1b6da"
                        ],
                        [
                            0.4,
                            "#fde0ef"
                        ],
                        [
                            0.5,
                            "#f7f7f7"
                        ],
                        [
                            0.6,
                            "#e6f5d0"
                        ],
                        [
                            0.7,
                            "#b8e186"
                        ],
                        [
                            0.8,
                            "#7fbc41"
                        ],
                        [
                            0.9,
                            "#4d9221"
                        ],
                        [
                            1,
                            "#276419"
                        ]
                    ],
                    "sequential": [
                        [
                            0,
                            "#0508b8"
                        ],
                        [
                            0.0893854748603352,
                            "#1910d8"
                        ],
                        [
                            0.1787709497206704,
                            "#3c19f0"
                        ],
                        [
                            0.2681564245810056,
                            "#6b1cfb"
                        ],
                        [
                            0.3575418994413408,
                            "#981cfd"
                        ],
                        [
                            0.44692737430167595,
                            "#bf1cfd"
                        ],
                        [
                            0.5363128491620112,
                            "#dd2bfd"
                        ],
                        [
                            0.6256983240223464,
                            "#f246fe"
                        ],
                        [
                            0.7150837988826816,
                            "#fc67fd"
                        ],
                        [
                            0.8044692737430168,
                            "#fe88fc"
                        ],
                        [
                            0.8938547486033519,
                            "#fea5fd"
                        ],
                        [
                            0.9832402234636871,
                            "#febefe"
                        ],
                        [
                            1,
                            "#fec3fe"
                        ]
                    ],
                    "sequentialminus": [
                        [
                            0,
                            "#0508b8"
                        ],
                        [
                            0.0893854748603352,
                            "#1910d8"
                        ],
                        [
                            0.1787709497206704,
                            "#3c19f0"
                        ],
                        [
                            0.2681564245810056,
                            "#6b1cfb"
                        ],
                        [
                            0.3575418994413408,
                            "#981cfd"
                        ],
                        [
                            0.44692737430167595,
                            "#bf1cfd"
                        ],
                        [
                            0.5363128491620112,
                            "#dd2bfd"
                        ],
                        [
                            0.6256983240223464,
                            "#f246fe"
                        ],
                        [
                            0.7150837988826816,
                            "#fc67fd"
                        ],
                        [
                            0.8044692737430168,
                            "#fe88fc"
                        ],
                        [
                            0.8938547486033519,
                            "#fea5fd"
                        ],
                        [
                            0.9832402234636871,
                            "#febefe"
                        ],
                        [
                            1,
                            "#fec3fe"
                        ]
                    ]
                },
                "plot_bgcolor": "white",
                "paper_bgcolor": "white",
                "shapedefaults": {
                    "line": {
                        "width": 0
                    },
                    "opacity": 0.4,
                    "fillcolor": "#506784"
                },
                "annotationdefaults": {
                    "arrowhead": 0,
                    "arrowcolor": "#506784",
                    "arrowwidth": 1
                }
            },
            "themeRef": "PLOTLY_WHITE"
        },
        "showlegend": true
    },
    "frames": []
}