var figure = {
    "data": [
        {
            "meta": {
                "columnNames": {
                    "x": "B81, x",
                    "y": "B81, y"
                }
            },
            "mode": "lines",
            "name": "Burnier (1981) E2 0.5 mg s.l.",
            "type": "scatter",
            "xsrc": "transfemscience:16:b2c271",
            "x": [
                "0",
                "1",
                "2",
                "4",
                "6",
                "8",
                "10",
                "24"
            ],
            "ysrc": "transfemscience:16:f6e24d",
            "y": [
                "23.4",
                "773.6",
                "402.2",
                "133.4",
                "82.0",
                "68.8",
                "47.6",
                "24.4"
            ]
        },
        {
            "meta": {
                "columnNames": {
                    "x": "C81, x",
                    "y": "C81, y"
                }
            },
            "mode": "lines",
            "name": "Casper & Yen (1981) E2 2 mg s.l.",
            "type": "scatter",
            "xsrc": "transfemscience:16:d6e827",
            "x": [
                "0",
                "0.0872864106817568",
                "0.18435289687668543",
                "0.406210500605531",
                "0.5265639470390093",
                "0.815125024170321",
                "1.0347335158404665",
                "1.2913745026002168",
                "1.5454203600614695",
                "1.762580779760027",
                "2.026237266056727",
                "2.2746170912162516",
                "2.495825912620469",
                "2.801142874589104",
                "3.030612857593553",
                "3.307513153743601",
                "3.500305309329235",
                "4.012281067768495",
                "4.495113524185587",
                "4.996959627929698",
                "5.4899217390419395",
                "6.513977061092396",
                "7.507643419057409",
                "8.50338588046122",
                "24"
            ],
            "ysrc": "transfemscience:16:65e9cc",
            "y": [
                "43.295915978872586",
                "88.39417469799815",
                "231.6234314733211",
                "350.63249916039945",
                "431.5298032790222",
                "307.72992336735837",
                "249.99542036006153",
                "233.18101790130373",
                "204.73941848749763",
                "177.70325968593852",
                "150.65437966232793",
                "138.4934002299998",
                "129.59566867831597",
                "122.53539043974729",
                "108.98423586163386",
                "99.60615096528636",
                "88.39061275582378",
                "90.57611870426723",
                "87.18820284751843",
                "85.65555001475656",
                "85.98579293921301",
                "90.82189271430178",
                "84.50351614577505",
                "87.48689714128699",
                "52.721323821251644"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "F82, x",
                    "y": "F82, y"
                }
            },
            "mode": "lines",
            "name": "Fiet (1982) E2 0.5 mg s.l.",
            "type": "scatter",
            "xsrc": "transfemscience:16:bd6de3",
            "x": [
                "0",
                "0.5",
                "1",
                "2",
                "4",
                "8",
                "16",
                "24"
            ],
            "ysrc": "transfemscience:16:c0b48a",
            "y": [
                "14.481067828929447",
                "89.70307818033234",
                "80.63198038681558",
                "63.49768455461727",
                "40.31599019340779",
                "39.3080904385726",
                "36.28439117406701",
                "34.268591664396624"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "P97 0.25, x",
                    "y": "P97 0.25, y"
                }
            },
            "mode": "lines",
            "name": "Price (1997) E2 0.25 mg s.l.",
            "type": "scatter",
            "xsrc": "transfemscience:16:bc82c2",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4",
                "6",
                "8",
                "12",
                "18",
                "24"
            ],
            "ysrc": "transfemscience:16:1a4e89",
            "y": [
                "5",
                "294",
                "122.56630898275046",
                "64.52892765016583",
                "43.429970870549425",
                "22.730776317405713",
                "15.32086265288578",
                "9.882517065295616",
                "5.829224209030144",
                "5.489475669889657"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "P97 0.5, x",
                    "y": "P97 0.5, y"
                }
            },
            "mode": "lines",
            "name": "Price (1997) E2 0.5 mg s.l.",
            "type": "scatter",
            "xsrc": "transfemscience:16:7237e4",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4",
                "6",
                "8",
                "12",
                "18",
                "24"
            ],
            "ysrc": "transfemscience:16:d13cf3",
            "y": [
                "5",
                "245",
                "141.91460333058416",
                "64.52892765016583",
                "46.16612122062929",
                "31.329908575640047",
                "24.50651025672525",
                "19.26360397985505",
                "10.715404390475044",
                "8.812141365574632"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "P97 1, x",
                    "y": "P97 1, y"
                }
            },
            "mode": "lines",
            "name": "Price (1997) E2 1 mg s.l.",
            "type": "scatter",
            "xsrc": "transfemscience:16:214e65",
            "x": [
                "0",
                "1",
                "2",
                "3",
                "4",
                "6",
                "8",
                "12",
                "18",
                "24"
            ],
            "ysrc": "transfemscience:16:5243f2",
            "y": [
                "5",
                "451",
                "215.62020202020227",
                "116.12510309368804",
                "85.44942267534702",
                "56.73721638268378",
                "44.0506387421693",
                "34.50787021601417",
                "24.59159545159426",
                "24.056407601733753"
            ],
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "A98, x",
                    "y": "A98, y"
                }
            },
            "mode": "lines",
            "name": "Al-Khalili (1998) E2 2 mg s.l.",
            "type": "scatter",
            "xsrc": "transfemscience:16:986813",
            "x": [
                "0",
                "0.25",
                "0.5",
                "1",
                "2",
                "4",
                "8"
            ],
            "ysrc": "transfemscience:16:3071bb",
            "y": [
                "0",
                "467.0824532454026",
                "966.2545406832378",
                "1362.0266957232361",
                "862.8546082854004",
                "492.041057617294",
                "363.6825208475648"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "W03 1x, x",
                    "y": "W03 1x, y"
                }
            },
            "mode": "lines",
            "name": "Wren (2003) E2 0.25 mg single b.c.",
            "type": "scatter",
            "xsrc": "transfemscience:16:27561b",
            "x": [
                "0",
                "0.25",
                "0.5",
                "0.75",
                "1",
                "1.5",
                "2",
                "3",
                "4",
                "6",
                "8",
                "12"
            ],
            "ysrc": "transfemscience:16:b2bf44",
            "y": [
                "20.0185454841042",
                "174.0420869237874",
                "337.6404902030744",
                "422.9157216450435",
                "458.57602994824316",
                "308.8550128996461",
                "178.27183820642924",
                "112.92752748533562",
                "61.51703928311333",
                "36.13259092534862",
                "25.549301725873192",
                "13.954614835569664"
            ],
            "visible": true,
            "stackgroup": null
        },
        {
            "meta": {
                "columnNames": {
                    "x": "W03 2x/d, x",
                    "y": "W03 2x/d, y"
                }
            },
            "mode": "lines",
            "name": "Wren (2003) E2 0.25 mg 2x/day b.c. ",
            "type": "scatter",
            "xsrc": "transfemscience:16:3bc527",
            "x": [
                "0",
                "0.25",
                "0.5",
                "0.75",
                "1",
                "1.5",
                "2",
                "2.5",
                "3",
                "4",
                "6",
                "8",
                "10",
                "12"
            ],
            "ysrc": "transfemscience:16:ced694",
            "y": [
                "26.982486412582997",
                "234.09920854157883",
                "462.1003276286185",
                "481.22777382564936",
                "497.74578427703364",
                "385.4449966236063",
                "177.40153123605424",
                "121.67069665700423",
                "98.13973481635219",
                "76.30928744853203",
                "50.92929458720261",
                "36.864777506227206",
                "34.1201917020411",
                "24.40720947294078"
            ],
            "visible": true,
            "stackgroup": null
        }
    ],
    "layout": {
        "font": {
            "color": "rgb(68, 68, 68)"
        },
        "title": {
            "x": 0.5,
            "font": {
                "size": 16
            },
            "text": "Sublingual and Buccal Estradiol"
        },
        "width": 644,
        "xaxis": {
            "type": "linear",
            "dtick": 2,
            "range": [
                -0.5,
                24.5
            ],
            "title": {
                "text": "Time (hours)"
            },
            "tickmode": "linear",
            "autorange": false,
            "zerolinecolor": "rgb(68, 68, 68)",
            "zerolinewidth": 1
        },
        "yaxis": {
            "type": "linear",
            "range": [
                -75.66814976240201,
                1437.694845485638
            ],
            "title": {
                "text": "Estradiol levels (pg/mL)"
            },
            "autorange": true,
            "zerolinecolor": "rgb(68, 68, 68)",
            "zerolinewidth": 1
        },
        "height": 450,
        "legend": {
            "x": 0.45124999999999993,
            "y": 0.9250814332247557
        },
        "autosize": false,
        "template": {
            "data": {
                "bar": [
                    {
                        "type": "bar",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "table": [
                    {
                        "type": "table",
                        "cells": {
                            "fill": {
                                "color": "#EBF0F8"
                            },
                            "line": {
                                "color": "white"
                            }
                        },
                        "header": {
                            "fill": {
                                "color": "#C8D4E3"
                            },
                            "line": {
                                "color": "white"
                            }
                        }
                    }
                ],
                "carpet": [
                    {
                        "type": "carpet",
                        "aaxis": {
                            "gridcolor": "#C8D4E3",
                            "linecolor": "#C8D4E3",
                            "endlinecolor": "#2a3f5f",
                            "minorgridcolor": "#C8D4E3",
                            "startlinecolor": "#2a3f5f"
                        },
                        "baxis": {
                            "gridcolor": "#C8D4E3",
                            "linecolor": "#C8D4E3",
                            "endlinecolor": "#2a3f5f",
                            "minorgridcolor": "#C8D4E3",
                            "startlinecolor": "#2a3f5f"
                        }
                    }
                ],
                "mesh3d": [
                    {
                        "type": "mesh3d",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "contour": [
                    {
                        "type": "contour",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ],
                "heatmap": [
                    {
                        "type": "heatmap",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ],
                "scatter": [
                    {
                        "type": "scatter",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "surface": [
                    {
                        "type": "surface",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "heatmapgl": [
                    {
                        "type": "heatmapgl",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "histogram": [
                    {
                        "type": "histogram",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "parcoords": [
                    {
                        "line": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        },
                        "type": "parcoords"
                    }
                ],
                "scatter3d": [
                    {
                        "type": "scatter3d",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scattergl": [
                    {
                        "type": "scattergl",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "choropleth": [
                    {
                        "type": "choropleth",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "scattergeo": [
                    {
                        "type": "scattergeo",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "histogram2d": [
                    {
                        "type": "histogram2d",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ],
                "scatterpolar": [
                    {
                        "type": "scatterpolar",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "contourcarpet": [
                    {
                        "type": "contourcarpet",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        }
                    }
                ],
                "scattercarpet": [
                    {
                        "type": "scattercarpet",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scattermapbox": [
                    {
                        "type": "scattermapbox",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scatterpolargl": [
                    {
                        "type": "scatterpolargl",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "scatterternary": [
                    {
                        "type": "scatterternary",
                        "marker": {
                            "colorbar": {
                                "ticks": "",
                                "outlinewidth": 0
                            }
                        }
                    }
                ],
                "histogram2dcontour": [
                    {
                        "type": "histogram2dcontour",
                        "colorbar": {
                            "ticks": "",
                            "outlinewidth": 0
                        },
                        "autocolorscale": true
                    }
                ]
            },
            "layout": {
                "geo": {
                    "bgcolor": "white",
                    "showland": true,
                    "lakecolor": "white",
                    "landcolor": "white",
                    "showlakes": true,
                    "subunitcolor": "#C8D4E3"
                },
                "font": {
                    "color": "#2a3f5f"
                },
                "polar": {
                    "bgcolor": "white",
                    "radialaxis": {
                        "ticks": "",
                        "gridcolor": "#EBF0F8",
                        "linecolor": "#EBF0F8"
                    },
                    "angularaxis": {
                        "ticks": "",
                        "gridcolor": "#EBF0F8",
                        "linecolor": "#EBF0F8"
                    }
                },
                "scene": {
                    "xaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "gridwidth": 2,
                        "linecolor": "#EBF0F8",
                        "zerolinecolor": "#EBF0F8",
                        "showbackground": true,
                        "backgroundcolor": "white"
                    },
                    "yaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "gridwidth": 2,
                        "linecolor": "#EBF0F8",
                        "zerolinecolor": "#EBF0F8",
                        "showbackground": true,
                        "backgroundcolor": "white"
                    },
                    "zaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "gridwidth": 2,
                        "linecolor": "#EBF0F8",
                        "zerolinecolor": "#EBF0F8",
                        "showbackground": true,
                        "backgroundcolor": "white"
                    }
                },
                "title": {
                    "x": 0.05
                },
                "xaxis": {
                    "ticks": "",
                    "gridcolor": "#EBF0F8",
                    "linecolor": "#EBF0F8",
                    "automargin": true,
                    "zerolinecolor": "#EBF0F8",
                    "zerolinewidth": 2
                },
                "yaxis": {
                    "ticks": "",
                    "gridcolor": "#EBF0F8",
                    "linecolor": "#EBF0F8",
                    "automargin": true,
                    "zerolinecolor": "#EBF0F8",
                    "zerolinewidth": 2
                },
                "ternary": {
                    "aaxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "linecolor": "#A2B1C6"
                    },
                    "baxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "linecolor": "#A2B1C6"
                    },
                    "caxis": {
                        "ticks": "",
                        "gridcolor": "#DFE8F3",
                        "linecolor": "#A2B1C6"
                    },
                    "bgcolor": "white"
                },
                "colorway": [
                    "#636efa",
                    "#EF553B",
                    "#00cc96",
                    "#ab63fa",
                    "#19d3f3",
                    "#e763fa",
                    "#fecb52",
                    "#ffa15a",
                    "#ff6692",
                    "#b6e880"
                ],
                "hovermode": "closest",
                "colorscale": {
                    "diverging": [
                        [
                            0,
                            "#8e0152"
                        ],
                        [
                            0.1,
                            "#c51b7d"
                        ],
                        [
                            0.2,
                            "#de77ae"
                        ],
                        [
                            0.3,
                            "#f1b6da"
                        ],
                        [
                            0.4,
                            "#fde0ef"
                        ],
                        [
                            0.5,
                            "#f7f7f7"
                        ],
                        [
                            0.6,
                            "#e6f5d0"
                        ],
                        [
                            0.7,
                            "#b8e186"
                        ],
                        [
                            0.8,
                            "#7fbc41"
                        ],
                        [
                            0.9,
                            "#4d9221"
                        ],
                        [
                            1,
                            "#276419"
                        ]
                    ],
                    "sequential": [
                        [
                            0,
                            "#0508b8"
                        ],
                        [
                            0.0893854748603352,
                            "#1910d8"
                        ],
                        [
                            0.1787709497206704,
                            "#3c19f0"
                        ],
                        [
                            0.2681564245810056,
                            "#6b1cfb"
                        ],
                        [
                            0.3575418994413408,
                            "#981cfd"
                        ],
                        [
                            0.44692737430167595,
                            "#bf1cfd"
                        ],
                        [
                            0.5363128491620112,
                            "#dd2bfd"
                        ],
                        [
                            0.6256983240223464,
                            "#f246fe"
                        ],
                        [
                            0.7150837988826816,
                            "#fc67fd"
                        ],
                        [
                            0.8044692737430168,
                            "#fe88fc"
                        ],
                        [
                            0.8938547486033519,
                            "#fea5fd"
                        ],
                        [
                            0.9832402234636871,
                            "#febefe"
                        ],
                        [
                            1,
                            "#fec3fe"
                        ]
                    ],
                    "sequentialminus": [
                        [
                            0,
                            "#0508b8"
                        ],
                        [
                            0.0893854748603352,
                            "#1910d8"
                        ],
                        [
                            0.1787709497206704,
                            "#3c19f0"
                        ],
                        [
                            0.2681564245810056,
                            "#6b1cfb"
                        ],
                        [
                            0.3575418994413408,
                            "#981cfd"
                        ],
                        [
                            0.44692737430167595,
                            "#bf1cfd"
                        ],
                        [
                            0.5363128491620112,
                            "#dd2bfd"
                        ],
                        [
                            0.6256983240223464,
                            "#f246fe"
                        ],
                        [
                            0.7150837988826816,
                            "#fc67fd"
                        ],
                        [
                            0.8044692737430168,
                            "#fe88fc"
                        ],
                        [
                            0.8938547486033519,
                            "#fea5fd"
                        ],
                        [
                            0.9832402234636871,
                            "#febefe"
                        ],
                        [
                            1,
                            "#fec3fe"
                        ]
                    ]
                },
                "plot_bgcolor": "white",
                "paper_bgcolor": "white",
                "shapedefaults": {
                    "line": {
                        "width": 0
                    },
                    "opacity": 0.4,
                    "fillcolor": "#506784"
                },
                "annotationdefaults": {
                    "arrowhead": 0,
                    "arrowcolor": "#506784",
                    "arrowwidth": 1
                }
            },
            "themeRef": "PLOTLY_WHITE"
        }
    },
    "frames": []
}